#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QTcpServer>
#include<QTcpSocket>
#include<set>

#define Port 8000
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
private slots:
    void newClient();
    void delClient();
    void readCliend();
private:
    Ui::Widget *ui;
    QTcpServer *server;
    QList<QTcpSocket*> socket;
    std::map<QString,QString>roomIP;
    std::map<QString,QString>master;
    std::map<QString,int>roomnumber;
//    std::map<QString,QList<QString>>members;
    std::map<QString,int>number;
    std::map<QString,QString>IProom;
    std::map<QString,QString>IPID;
};
#endif // WIDGET_H
