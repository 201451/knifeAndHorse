#include "widget.h"
#include "ui_widget.h"
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    server=new QTcpServer;
    server->listen(QHostAddress::Any,Port);
    connect(server,SIGNAL(newConnection()),this,SLOT(newClient()));
    ui->label->setText("服务器 启动！！！");
    qDebug()<<"已启动";
}

Widget::~Widget()
{
    delete ui;
    for(auto tmp:socket) {
        tmp->write("5"); //5表示服务器崩溃
        tmp->flush();
    }
}
void Widget::delClient() {
    QTcpSocket* tmp=qobject_cast<QTcpSocket*>(sender());
    QString tmpIP=tmp->peerAddress().toString();

    QString mas=master[tmpIP];

    qDebug()<<"room"+IProom[mas]+" of master "+mas+" has destroyed";

    roomIP.erase(IProom[mas]);
    IProom.erase(mas);
    roomnumber.erase(mas);
    std::vector<QTcpSocket*>del;
    for(auto tmpsocket:socket) {
        QString ipAddress=tmpsocket->peerAddress().toString();
        if(master[ipAddress]==mas) {
            del.push_back(tmpsocket);
            tmpsocket->write("4");//4表示家没了
            tmpsocket->flush();
            IPID.erase(ipAddress);
            master.erase(ipAddress);
        }
    }
    for(auto t:del) {
        socket.removeOne(t);
    }
    tmp->deleteLater();
}


void Widget::newClient() {
    QTcpSocket* tmp=server->nextPendingConnection();
    socket.append(tmp);
    qDebug() << "New client connected:" << tmp->peerAddress().toString();
    qDebug()<<"now there is "<<socket.size()<< " members";
    connect(tmp,SIGNAL(disconnected()),this,SLOT(delClient()));
    connect(tmp,SIGNAL(readyRead()),this,SLOT(readCliend()));
}


void Widget::readCliend() {
    qDebug()<<"READ";
    QTcpSocket* tmp=qobject_cast<QTcpSocket*>(sender());
    QByteArray data=tmp->readAll();
    //传入房间格式：“房间号+0/1” 0表示创建房间，1表示加入房间，2表示传入信息,3表示查询房间成员，4表示传入ID
    QString room = data.left(data.indexOf('+'));
    QString status = data.mid(data.indexOf('+') + 1);
    //输出格式：0/1表示失败/成功
    //2表示传出给所有成员，后面紧跟信息
    //3表示传出房间成员，后面紧跟房主+成员ID1+成员ID2+...
    if(status=="0") {
        if(roomIP.count(room)) {
    //        tmp->write("0");
    //        tmp->flush();
            qDebug()<<"Sorry,zujian defeat";
        } else {
            QString tmpip=tmp->peerAddress().toString();
            roomIP[room]=tmpip;
            IProom[tmpip]=room;
            roomnumber[tmpip]=1;
            number[tmpip]=0;
            master[tmpip]=tmpip;
//            members[tmpip].clear();
            tmp->write("1");
            tmp->flush();
            qDebug()<<tmpip+" zujian room " + room+" successfully!";

            QString ret=(std::string(1,8)+std::string(1,roomnumber[tmpip])).c_str();
            ret+=IPID[tmpip];
            tmp->write(ret.toStdString().c_str());
            tmp->flush();
        }
    } else if(status=="1"){
        if(roomIP.count(room)&&roomnumber[room]<8) {
            QString tmpip=tmp->peerAddress().toString();
    //        tmp->write("1");
            number[tmpip]=roomnumber[roomIP[room]];
            ++roomnumber[roomIP[room]];
            master[tmpip]=roomIP[room];
//            members[master[tmpip]].append(tmpip);
    //        tmp->flush();
            qDebug()<<tmpip+" jiaru room "+room+" successfully and the master is " +master[tmpip];

            QString mas=master[tmpip];
            QString ret=(std::string(1,8)+std::string(1,roomnumber[mas])).c_str();
            ret+=IPID[mas];
            for(auto t:socket) {
                if(mas==master[t->peerAddress().toString()]&&mas!=t->peerAddress().toString()) {
                    ret+=" ";
                    ret+=IPID[t->peerAddress().toString()];
                }
            }
            for(auto t:socket) {
                QString ipAddress=tmp->peerAddress().toString();
                if(master[ipAddress]==master[tmpip]) {
                    t->write(ret.toStdString().c_str());
                    t->flush();
                }
            }
        } else {
            tmp->write("0");
            tmp->flush();
            qDebug()<<"jiaru wrong";
        }
    } else if(status=="4"){
        QString tmpip=tmp->peerAddress().toString();
        IPID[tmpip]=room;
    }else if(status=="2") {
        qDebug()<<"zz:"<<int(data.at(0));

        if(data.at(0)==9) {
            {
                qDebug()<<"receive";
                QString tmpip=tmp->peerAddress().toString();
                qDebug()<<tmpip;
                QString mas=master[tmpip];
                qDebug()<<mas;
                for(auto t:socket) {
                    QString ipAddress=t->peerAddress().toString();
                    if(mas==master[ipAddress]) {

                        std::string ret=std::string(1,10);
                        if(number[ipAddress]==0) ret+="&";
                        else ret+=number[ipAddress];
                        ret+=room.toStdString();
                        qDebug()<<ipAddress;
                        qDebug()<<ret;
                        t->write(ret.c_str());
                        t->flush();
                    }
                }
            }
        }
        QString tmpip=tmp->peerAddress().toString();
        QString mas=master[tmpip];
        for(auto t:socket) {
            if(mas==master[t->peerAddress().toString()]) {
                qDebug()<<t->peerAddress().toString();
                qDebug()<<"###"<<int((room.toStdString())[0])<<int((room.toStdString())[1])<<(int)(room.toStdString())[2];
                t->waitForBytesWritten();
                t->write((room.toStdString()).c_str());
                qDebug() << (room.toStdString()).c_str();
                t->flush();
            }
        }
    }
}
