#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

//界面1， 开始界面
//ui->btn1 开始游戏
//ui->btn2 游戏规则
//ui->btn3 选项
//ui->btn4 退出

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Form1 : public QWidget
{
    Q_OBJECT

public:
    Form1(QWidget *parent = nullptr);
    ~Form1();

private slots:

private:
    Ui::Widget *ui;
};
#endif // WIDGET_H
