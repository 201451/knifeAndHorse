#include "form6.h"
#include "ui_form6.h"
#include "formmanage.h"

Form6::Form6(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form6)
{
    ui->setupUi(this);
    connect(ui->toolButton, &QToolButton::clicked, this, [=](){
        //加入队伍
    });
    connect(ui->toolButton_2, &QToolButton::clicked, this, [=](){});
    connect(ui->toolButton_3, &QToolButton::clicked, this, [=](){});
    connect(ui->toolButton_4, &QToolButton::clicked, this, [=](){});
    connect(ui->toolButton_5, &QToolButton::clicked, this, [=](){});
    connect(ui->toolButton_6, &QToolButton::clicked, this, [=](){});
    connect(ui->toolButton_7, &QToolButton::clicked, this, [=](){});
    connect(ui->toolButton_8, &QToolButton::clicked, this, [=](){});

    //开始选择英雄（房主显示）
    connect(ui->toolButton_9, &QToolButton::clicked, this, [=](){
        fms.fm7->show();
        this->hide();
    });
}

Form6::~Form6()
{
    delete ui;
}
