#include "formmanage.h"

FormManage fms;
FormManage::FormManage()
{
}
void FormManage::open()
{
    fm1 = new Form1();
    fm2 = new Form2();
    fm3 = new Form3();
    fm4 = new Form4();
    fm5 = new Form5();
    fm6 = new Form6();
    fm7 = new Form7();
    fm8 = new Form8();
}
FormManage::~FormManage()
{
    delete fm1;
    delete fm2;
    delete fm3;
    delete fm4;
    delete fm5;
    delete fm6;
    delete fm7;
    delete fm8;
}
