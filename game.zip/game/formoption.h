#ifndef FORMOPTION_H
#define FORMOPTION_H

#include <QWidget>

namespace Ui {
class FormOption;
}

class FormOption : public QWidget
{
    Q_OBJECT

public:
    explicit FormOption(QWidget *parent = nullptr);
    ~FormOption();
    void set_back_form(QWidget *);  //设置返回到哪个界面
private:
    Ui::FormOption *ui;
    QWidget *back;          //返回界面
};

#endif // FORMOPTION_H
