//选择英雄界面

#ifndef FORM7_H
#define FORM7_H

#include <QWidget>

namespace Ui {
class Form7;
}

class Form7 : public QWidget
{
    Q_OBJECT

public:
    explicit Form7(QWidget *parent = nullptr);
    ~Form7();
    int role=0;
private slots:
    void on_toolButton_clicked();

    void on_toolButton_2_clicked();
    void on_toolButton_3_clicked();
    void on_toolButton_4_clicked();
    void on_toolButton_5_clicked();
    void on_toolButton_6_clicked();
    void on_toolButton_7_clicked();
    void on_toolButton_8_clicked();
    void on_toolButton_9_clicked();

    void on_readyButton_clicked();

private:
    Ui::Form7 *ui;
};

#endif // FORM7_H
