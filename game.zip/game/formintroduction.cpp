


#include "formintroduction.h"
#include "ui_formintroduction.h"

FormIntroduction::FormIntroduction(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormIntroduction)
{
    ui->setupUi(this);
    ui->scrollArea->setWidget(ui->label);

    connect(ui->toolButton, &QToolButton::clicked, this, [=](){
        this->back->show();
        delete this;
    });
}

void FormIntroduction::set_back_form(QWidget *b) {
    back = b;
}
FormIntroduction::~FormIntroduction()
{
    delete ui;
}
