#include "form2.h"
#include "ui_form2.h"
#include "formmanage.h"
#include <QDebug>
#include "game.h"
#include "client.h"

Form2::Form2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form2)
{
    ui->setupUi(this);
    connect(ui->toolButton, &QToolButton::clicked, this, [=](){
        fms.fm3->show();
        this->hide();
    });
}

Form2::~Form2()
{
    delete ui;
}

void Form2::on_toolButton_clicked()
{
    game.name = ui->lineEdit->text();
    client->socket->write((game.name + QString::fromStdString("+4")).toStdString().c_str());
}

