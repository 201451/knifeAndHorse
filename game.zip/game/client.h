#ifndef CLIENT_H
#define CLIENT_H

#include<QTcpSocket>
#include<QTcpServer>
#include<QHostInfo>
#include <QWidget>

#define IP "10.129.215.213"
#define Port 8000
#define Port2 6666

class Client : public QWidget
{
    Q_OBJECT

public:
    Client(QWidget *parent = nullptr);
    ~Client();
    QTcpSocket *socket;
    void roomAddress();
private slots:

private:
    bool fangzhu,zujian=1;
};
extern Client *client;
#endif // WIDGET_H
