#ifndef FORMMANAGE_H
#define FORMMANAGE_H

#include "form1.h"
#include "form2.h"
#include "form3.h"
#include "form4.h"
#include "form5.h"
#include "form6.h"
#include "form7.h"
#include "form8.h"

#include "formintroduction.h"
#include "formoption.h"

//保存所有的窗口
class FormManage
{
public:
    FormManage();
    ~FormManage();
    void open();
    Form1 *fm1;
    Form2 *fm2;
    Form3 *fm3;
    Form4 *fm4;
    Form5 *fm5;
    Form6 *fm6;
    Form7 *fm7;
    Form8 *fm8;
};
extern FormManage fms;
#endif // FORMMANAGE_H
