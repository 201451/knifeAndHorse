//主要游戏界面
#include "form8.h"
#include "ui_form8.h"
#include "formmanage.h"
#include <QDebug>
#include <game.h>
#include <QImage>

Form8::Form8(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form8)
{
    ui->setupUi(this);
    QImage *img = new QImage;
    img->load(":/res_items/bg.png");
   // *nimg = img->scaled()
    *img = img->scaled(img->width() * 0.75, img->height() * 0.75, Qt::KeepAspectRatio);
    qDebug() << img->width() << " " << img->height();
    ui->label->setGeometry(0, 0, img->width(), img->height());
    int bgx = img->width(), bgy = img->height();
    ui->label->setPixmap(QPixmap::fromImage(*img));

    img->load(":/res_items/c.png");
    *img = img->scaled(img->width() / 3, img->height() / 3, Qt::KeepAspectRatio);
    ui->label_3->setGeometry(bgx + 2, 0, img->width(), img->height());
    ui->label_3->setPixmap(QPixmap::fromImage(*img));

    this->resize(1038, 749);
    qDebug() << bgx + 5 + img->width() << " "<<img->height() + 80;

    ui->btn_mv_0->move(228,2);
    ui->btn_mv_1->move(390,65);
    ui->btn_mv_2->move(456,226);
    ui->btn_mv_3->move(395,388);
    ui->btn_mv_4->move(233,456);
    ui->btn_mv_5->move(69,393);
    ui->btn_mv_6->move(3,231);
    ui->btn_mv_7->move(66,68);
    ui->btn_mv_8->move(160,156);


    ui->hp_0->move(637, 12);
    ui->hp_1->move(637, 12+74);
    ui->hp_2->move(637, 12+74*2);
    ui->hp_3->move(637, 12+74*3);
    ui->hp_4->move(637, 12+74*4);
    ui->hp_5->move(637, 12+74*5);
    ui->hp_6->move(637, 12+74*6);
    ui->hp_7->move(637, 12+74*7);

    ui->rem_0->move(637, 49);
    ui->rem_1->move(637, 49+74);
    ui->rem_2->move(637, 49+74*2);
    ui->rem_3->move(637, 49+74*3);
    ui->rem_4->move(637, 49+74*4);
    ui->rem_5->move(637, 49+74*5);
    ui->rem_6->move(637, 49+74*6);
    ui->rem_7->move(637, 49+74*7);

    ui->name_0->move(666, 44);
    ui->name_1->move(666, 44+74);
    ui->name_2->move(666, 44+74*2);
    ui->name_3->move(666, 44+74*3);
    ui->name_4->move(666, 44+74*4);
    ui->name_5->move(666, 44+74*5);
    ui->name_6->move(666, 44+74*6);
    ui->name_7->move(666, 44+74*7);

    ui->role_0->move(666, 57);
    ui->role_1->move(666, 57+74);
    ui->role_2->move(666, 57+74*2);
    ui->role_3->move(666, 57+74*3);
    ui->role_4->move(666, 57+74*4);
    ui->role_5->move(666, 57+74*5);
    ui->role_6->move(666, 57+74*6);
    ui->role_7->move(666, 57+74*7);

    ui->icon_0->close();
    ui->icon_1->close();
    ui->icon_2->close();
    ui->icon_3->close();
    ui->icon_4->close();
    ui->icon_5->close();
    ui->icon_6->close();
    ui->icon_7->close();

    ui->name_0->close();
    ui->name_1->close();
    ui->name_2->close();
    ui->name_3->close();
    ui->name_4->close();
    ui->name_5->close();
    ui->name_6->close();
    ui->name_7->close();

    ui->hp_0->close();
    ui->hp_1->close();
    ui->hp_2->close();
    ui->hp_3->close();
    ui->hp_4->close();
    ui->hp_5->close();
    ui->hp_6->close();
    ui->hp_7->close();

    ui->rem_0->close();
    ui->rem_1->close();
    ui->rem_2->close();
    ui->rem_3->close();
    ui->rem_4->close();
    ui->rem_5->close();
    ui->rem_6->close();
    ui->rem_7->close();

    ui->role_0->close();
    ui->role_1->close();
    ui->role_2->close();
    ui->role_3->close();
    ui->role_4->close();
    ui->role_5->close();
    ui->role_6->close();
    ui->role_7->close();
}

Form8::~Form8()
{
    delete ui;
}

void Form8::on_toolButton_9_clicked()
{
    game.click_guess(rand()%3+1);
}



void Form8::on_toolButton_12_clicked()
{
    game.click_guess(1);
}


void Form8::on_toolButton_11_clicked()
{
    game.click_guess(2);
}


void Form8::on_toolButton_13_clicked()
{
    game.click_guess(3);
}




void Form8::on_toolButton1_clicked()
{
    game.click_move();
}


void Form8::on_toolButton2_clicked()
{
    game.click_attack();
}



void Form8::on_toolButton3_clicked()
{
    game.click_buy();
}


void Form8::on_toolButton3_2_clicked()
{
    game.click_rob();
}


void Form8::on_toolButton_4_clicked()
{
    game.hide_button_back();
    game.hide_highlight_position_move();
    game.hide_highlight_player_move();
    game.hide_highlight_player_rob();
    game.hide_button_buy_thing();
    game.hide_button_rob_thing();
    game.hide_button_attack_thing();
    game.hide_highlight_position_attack();
    game.hide_highlight_player_attack();
    game.show_button_action();
}


void Form8::on_toolButton_a_0_clicked()
{
    game.click_attack_what(game.thing[0]);
}
void Form8::on_toolButton_a_1_clicked()
{
    game.click_attack_what(game.thing[1]);
}

void Form8::on_toolButton_a_2_clicked()
{
    game.click_attack_what(game.thing[2]);
}

void Form8::on_toolButton_a_3_clicked()
{
    game.click_attack_what(game.thing[3]);
}

void Form8::on_toolButton_a_4_clicked()
{
    game.click_attack_what(game.thing[4]);
}

void Form8::on_toolButton_a_5_clicked()
{
    game.click_attack_what(game.thing[5]);
}

void Form8::on_toolButton_a_6_clicked()
{
    game.click_attack_what(game.thing[6]);
}

void Form8::on_toolButton_a_7_clicked()
{
    game.click_attack_what(game.thing[7]);
}

void Form8::on_toolButton_a_8_clicked()
{
    game.click_attack_what(game.thing[8]);
}

void Form8::on_toolButton_a_9_clicked()
{
    game.click_attack_what(game.thing[9]);
}

void Form8::on_toolButton_a_10_clicked()
{
    game.click_attack_what(game.thing[10]);
}

void Form8::on_toolButton_a_11_clicked()
{
    game.click_attack_what(game.thing[11]);
}

void Form8::on_toolButton_a_12_clicked()
{
    game.click_attack_what(game.thing[12]);
}

void Form8::on_toolButton_a_13_clicked()
{
    game.click_attack_what(game.thing[13]);
}


void Form8::on_toolButton_b_0_clicked()
{
    game.click_buy_what(game.thing[0]);
}
void Form8::on_toolButton_b_1_clicked()
{
    game.click_buy_what(game.thing[1]);
}

void Form8::on_toolButton_b_2_clicked()
{
    game.click_buy_what(game.thing[2]);
}

void Form8::on_toolButton_b_3_clicked()
{
    game.click_buy_what(game.thing[3]);
}

void Form8::on_toolButton_b_4_clicked()
{
    game.click_buy_what(game.thing[4]);
}

void Form8::on_toolButton_b_5_clicked()
{
    game.click_buy_what(game.thing[5]);
}

void Form8::on_toolButton_b_6_clicked()
{
    game.click_buy_what(game.thing[6]);
}

void Form8::on_toolButton_b_7_clicked()
{
    game.click_buy_what(game.thing[7]);
}

void Form8::on_toolButton_b_8_clicked()
{
    game.click_buy_what(game.thing[8]);
}

void Form8::on_toolButton_b_9_clicked()
{
    game.click_buy_what(game.thing[9]);
}

void Form8::on_toolButton_b_10_clicked()
{
    game.click_buy_what(game.thing[10]);
}

void Form8::on_toolButton_b_11_clicked()
{
    game.click_buy_what(game.thing[11]);
}

void Form8::on_toolButton_b_12_clicked()
{
    game.click_buy_what(game.thing[12]);
}

void Form8::on_toolButton_b_13_clicked()
{
    game.click_buy_what(game.thing[13]);
}



void Form8::on_toolButton_r_0_clicked()
{
    game.click_rob_who_what(game.thing[0]);
}
void Form8::on_toolButton_r_1_clicked()
{
    game.click_rob_who_what(game.thing[1]);
}

void Form8::on_toolButton_r_2_clicked()
{
    game.click_rob_who_what(game.thing[2]);
}

void Form8::on_toolButton_r_3_clicked()
{
    game.click_rob_who_what(game.thing[3]);
}

void Form8::on_toolButton_r_4_clicked()
{
    game.click_rob_who_what(game.thing[4]);
}

void Form8::on_toolButton_r_5_clicked()
{
    game.click_rob_who_what(game.thing[5]);
}

void Form8::on_toolButton_r_6_clicked()
{
    game.click_rob_who_what(game.thing[6]);
}

void Form8::on_toolButton_r_7_clicked()
{
    game.click_rob_who_what(game.thing[7]);
}

void Form8::on_toolButton_r_8_clicked()
{
    game.click_rob_who_what(game.thing[8]);
}

void Form8::on_toolButton_r_9_clicked()
{
    game.click_rob_who_what(game.thing[9]);
}

void Form8::on_toolButton_r_10_clicked()
{
    game.click_rob_who_what(game.thing[10]);
}

void Form8::on_toolButton_r_11_clicked()
{
    game.click_rob_who_what(game.thing[11]);
}

void Form8::on_toolButton_r_12_clicked()
{
    game.click_rob_who_what(game.thing[12]);
}

void Form8::on_toolButton_r_13_clicked()
{
    game.click_rob_who_what(game.thing[13]);
}

void Form8::on_toolButton_r_14_clicked()
{
    game.click_rob_who_what(game.thing[14]);
}



void Form8::on_btn0_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(0);
    } else if (game.information[0] == 1) {
        game.click_move_where_who(0);
    } else if (game.information[0] == 3) {
        game.click_rob_who(0);
    }
}
void Form8::on_btn1_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(1);
    } else if (game.information[0] == 1) {
        game.click_move_where_who(1);
    } else if (game.information[0] == 3) {
        game.click_rob_who(1);
    }
}

void Form8::on_btn2_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(2);
    } else if (game.information[0] == 1) {
        game.click_move_where_who(2);
    } else if (game.information[0] == 3) {
        game.click_rob_who(2);
    }
}

void Form8::on_btn3_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(3);
    } else if (game.information[0] == 1) {
        game.click_move_where_who(3);
    } else if (game.information[0] == 3) {
        game.click_rob_who(3);
    }
}

void Form8::on_btn4_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(4);
    } else if (game.information[0] == 1) {
        game.click_move_where_who(4);
    } else if (game.information[0] == 3) {
        game.click_rob_who(4);
    }
}

void Form8::on_btn5_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(5);
    } else if (game.information[0] == 1) {
        game.click_move_where_who(5);
    } else if (game.information[0] == 3) {
        game.click_rob_who(5);
    }
}

void Form8::on_btn6_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(6);
    } else if (game.information[0] == 1) {
        game.click_move_where_who(6);
    } else if (game.information[0] == 3) {
        game.click_rob_who(6);
    }
}

void Form8::on_btn7_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(7);
    } else if (game.information[0] == 1) {
        game.click_move_where_who(7);
    } else if (game.information[0] == 3) {
        game.click_rob_who(7);
    }
}



void Form8::on_btn_mv_0_clicked()
{
    qDebug() << "clicked";
    if (game.information[0] == 4) {
        game.click_attack_what_who(0);
    } else if (game.information[0] == 1) {
        game.click_move_where(0);
    }
}
void Form8::on_btn_mv_1_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(1);
    } else if (game.information[0] == 1) {
        game.click_move_where(1);
    }
}
void Form8::on_btn_mv_2_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(2);
    } else if (game.information[0] == 1) {
        game.click_move_where(2);
    }
}
void Form8::on_btn_mv_3_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(3);
    } else if (game.information[0] == 1) {
        game.click_move_where(3);
    }
}
void Form8::on_btn_mv_4_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(4);
    } else if (game.information[0] == 1) {
        game.click_move_where(4);
    }
}
void Form8::on_btn_mv_5_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(5);
    } else if (game.information[0] == 1) {
        game.click_move_where(5);
    }
}
void Form8::on_btn_mv_6_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(6);
    } else if (game.information[0] == 1) {
        game.click_move_where(6);
    }
}
void Form8::on_btn_mv_7_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(7);
    } else if (game.information[0] == 1) {
        game.click_move_where(7);
    }
}
void Form8::on_btn_mv_8_clicked()
{
    if (game.information[0] == 4) {
        game.click_attack_what_who(8);
    } else if (game.information[0] == 1) {
        game.click_move_where(8);
    }
}

