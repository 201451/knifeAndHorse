//规则介绍界面
//一个按钮返回到界面1(widget)

#ifndef FORMINTRODUCTION_H
#define FORMINTRODUCTION_H

#include <QWidget>


namespace Ui {
class FormIntroduction;
}

class FormIntroduction : public QWidget
{
    Q_OBJECT

public:
    explicit FormIntroduction(QWidget *parent = nullptr);
    ~FormIntroduction();
    void set_back_form(QWidget *);  //设置返回到哪个界面

private:
    Ui::FormIntroduction *ui;
    QWidget *back;          //返回界面
};

#endif // FORMINTRODUCTION_H
