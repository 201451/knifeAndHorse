#include "form5.h"
#include "ui_form5.h"
#include "formmanage.h"
#include "game.h"
Form5::Form5(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form5)
{
    ui->setupUi(this);
    //开始游戏
    connect(ui->toolButton, &QToolButton::clicked, this, [=](){
        game.information[0]=9;
        game.send(game.information);
    });
}
void Form5::show2()
{
    if (game.fz)
        ui->toolButton->show();
    else
        ui->toolButton->close();
    show();
}
Form5::~Form5()
{
    delete ui;
}
