#ifndef FORM8_H
#define FORM8_H

#include <QWidget>

namespace Ui {
class Form8;
}

class Form8 : public QWidget
{
    Q_OBJECT


public:
    explicit Form8(QWidget *parent = nullptr);
    ~Form8();

    friend class Game;
    int btn_size = 50*0.75;
private slots:
    void on_toolButton_9_clicked();

    void on_toolButton_12_clicked();

    void on_toolButton_11_clicked();

    void on_toolButton_13_clicked();

    void on_toolButton1_clicked();

    void on_toolButton2_clicked();

    void on_toolButton3_clicked();

    void on_toolButton3_2_clicked();

    void on_toolButton_4_clicked();

    void on_toolButton_a_0_clicked();
    void on_toolButton_a_1_clicked();
    void on_toolButton_a_2_clicked();
    void on_toolButton_a_3_clicked();
    void on_toolButton_a_4_clicked();
    void on_toolButton_a_5_clicked();
    void on_toolButton_a_6_clicked();
    void on_toolButton_a_7_clicked();
    void on_toolButton_a_8_clicked();
    void on_toolButton_a_9_clicked();
    void on_toolButton_a_10_clicked();
    void on_toolButton_a_11_clicked();
    void on_toolButton_a_12_clicked();
    void on_toolButton_a_13_clicked();

    void on_toolButton_b_0_clicked();
    void on_toolButton_b_1_clicked();
    void on_toolButton_b_2_clicked();
    void on_toolButton_b_3_clicked();
    void on_toolButton_b_4_clicked();
    void on_toolButton_b_5_clicked();
    void on_toolButton_b_6_clicked();
    void on_toolButton_b_7_clicked();
    void on_toolButton_b_8_clicked();
    void on_toolButton_b_9_clicked();
    void on_toolButton_b_10_clicked();
    void on_toolButton_b_11_clicked();
    void on_toolButton_b_12_clicked();
    void on_toolButton_b_13_clicked();

    void on_toolButton_r_0_clicked();
    void on_toolButton_r_1_clicked();
    void on_toolButton_r_2_clicked();
    void on_toolButton_r_3_clicked();
    void on_toolButton_r_4_clicked();
    void on_toolButton_r_5_clicked();
    void on_toolButton_r_6_clicked();
    void on_toolButton_r_7_clicked();
    void on_toolButton_r_8_clicked();
    void on_toolButton_r_9_clicked();
    void on_toolButton_r_10_clicked();
    void on_toolButton_r_11_clicked();
    void on_toolButton_r_12_clicked();
    void on_toolButton_r_13_clicked();
    void on_toolButton_r_14_clicked();


    void on_btn0_clicked();
    void on_btn1_clicked();
    void on_btn2_clicked();
    void on_btn3_clicked();
    void on_btn4_clicked();
    void on_btn5_clicked();
    void on_btn6_clicked();
    void on_btn7_clicked();

    void on_btn_mv_0_clicked();
    void on_btn_mv_1_clicked();
    void on_btn_mv_2_clicked();
    void on_btn_mv_3_clicked();
    void on_btn_mv_4_clicked();
    void on_btn_mv_5_clicked();
    void on_btn_mv_6_clicked();
    void on_btn_mv_7_clicked();
    void on_btn_mv_8_clicked();

private:
    Ui::Form8 *ui;
};

#endif // FORM8_H
