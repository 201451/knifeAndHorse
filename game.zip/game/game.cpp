#include "game.h"
#include "ui_form8.h"
#include "ui_form5.h"
#include "formmanage.h"
#include <QTimer>
#include <random>
#include <QPixmap>
#include <QDebug>
#include <QBitmap>
#include <QDialog>
#include "client.h"
#include <QElapsedTimer>

Game game;

int movexy[9][2] = {{322*3/4,37*3/4},{540*3/4,118*3/4},{631*3/4,331*3/4}
,{547*3/4,551*3/4},{325*3/4,644*3/4},{110*3/4,560*3/4}
,{24*3/4,346*3/4},{111*3/4,120*3/4},{311*3/4,321*3/4}};

int min(int x, int y) { return x < y ? x : y; }
void swap(int &x, int &y) { int z = x; x = y; y = z; }
Game::Game(QObject *parent)
    : QObject{parent}
{
    for (int i = 1; i <= 9; ++i) c[i] = 2;
    information.resize(10,'9');
}

bitset<9> Game::where_to_move(int x)
{
    bitset<9> flag;
    if(player[x].role==1&&player[x].equipment[3]) flag.set(),flag[player[x].position]=0;
    else if(player[x].position==8) flag.set(),flag[8]=0;
    else flag.reset(),flag[8]=1;
    return flag;
}
void Game::move(int x,int destination)
{
    player[x].position=destination;
//form8
    if (x == 0) {
        fms.fm8->ui->btn0->move(movexy[destination][0]+x%3*(fms.fm8->btn_size+3)
                            ,movexy[destination][1]+x/3*(fms.fm8->btn_size+3));
    } else if (x == 1) {
        fms.fm8->ui->btn1->move(movexy[destination][0]+x%3*(fms.fm8->btn_size+3)
                            ,movexy[destination][1]+x/3*(fms.fm8->btn_size+3));

    } else if (x == 2) {
        fms.fm8->ui->btn2->move(movexy[destination][0]+x%3*(fms.fm8->btn_size+3)
                            ,movexy[destination][1]+x/3*(fms.fm8->btn_size+3));

    } else if (x == 3) {
        fms.fm8->ui->btn3->move(movexy[destination][0]+x%3*(fms.fm8->btn_size+3)
                            ,movexy[destination][1]+x/3*(fms.fm8->btn_size+3));

    } else if (x == 4) {
        fms.fm8->ui->btn4->move(movexy[destination][0]+x%3*(fms.fm8->btn_size+3)
                            ,movexy[destination][1]+x/3*(fms.fm8->btn_size+3));

    } else if (x == 5) {
        fms.fm8->ui->btn5->move(movexy[destination][0]+x%3*(fms.fm8->btn_size+3)
                            ,movexy[destination][1]+x/3*(fms.fm8->btn_size+3));

    } else if (x == 6) {
        fms.fm8->ui->btn6->move(movexy[destination][0]+x%3*(fms.fm8->btn_size+3)
                            ,movexy[destination][1]+x/3*(fms.fm8->btn_size+3));

    } else if (x == 7) {
        fms.fm8->ui->btn7->move(movexy[destination][0]+x%3*(fms.fm8->btn_size+3)
                            ,movexy[destination][1]+x/3*(fms.fm8->btn_size+3));
    }
}
void Game::move_plus(int x,int destination,int y)
{
    move(x,destination);
    move(y,destination);
}
bitset<8> Game::who_to_touch(int x)//谁在 x 的身边
{
    bitset<8> flag;
    flag.reset();
    for(int i=0;i<n;i++)
        if(i!=x&&player[i].position==player[x].position)
            flag[i]=1;
    return flag;
}
bitset<8> Game::who_to_touch_plus(int x)//谁在 x 的身边
{
    bitset<8> flag;
    flag.reset();
    for(int i=0;i<n;i++)
        if(player[i].position==player[x].position)
            flag[i]=1;
    return flag;
}
void Game::rob(int x,int y,int equipment) // x 抢了 y 的 equipment
{
    player[x].equipment[equipment]++;
    player[y].equipment[equipment]--;
    rem[x]--;
}
void Game::buy(int x,int equipment)
{
    player[x].equipment[equipment+1]++;
    player[x].right[equipment]--;
    rem[x]-=cost[equipment];
}
bool Game::no_clothing(int x)
{
    return player[x].role==2||player[x].role==8||!player[x].equipment[0];
}
void Game::check(int x,int y)
{
    if(player[y].hp<=0)
    {
        for(int i=0;i<15;i++) player[x].equipment[i]+=player[y].equipment[i];
        player[y].die=1;
//form8
        if (y == 0) {
            fms.fm8->ui->btn0->close();
        } else if (y == 1) {
            fms.fm8->ui->btn1->close();
        } else if (y == 2) {
            fms.fm8->ui->btn2->close();
        } else if (y == 3) {
            fms.fm8->ui->btn3->close();
        } else if (y == 4) {
            fms.fm8->ui->btn4->close();
        } else if (y == 5) {
            fms.fm8->ui->btn5->close();
        } else if (y == 6) {
            fms.fm8->ui->btn6->close();
        } else if (y == 7) {
            fms.fm8->ui->btn7->close();
        }
    }
}
void Game::check(int x)
{
    if(player[x].hp<=0)
    {
        player[x].die=1;
//form8
        if (x == 0) {
            fms.fm8->ui->btn0->close();
        } else if (x == 1) {
            fms.fm8->ui->btn1->close();
        } else if (x == 2) {
            fms.fm8->ui->btn2->close();
        } else if (x == 3) {
            fms.fm8->ui->btn3->close();
        } else if (x == 4) {
            fms.fm8->ui->btn4->close();
        } else if (x == 5) {
            fms.fm8->ui->btn5->close();
        } else if (x == 6) {
            fms.fm8->ui->btn6->close();
        } else if (x == 7) {
            fms.fm8->ui->btn7->close();
        }
    }
}
void Game::rand_to_go(int x)
{
    if(player[x].position==8) move(x,x);
    else move(x,8);
}
void Game::attack(int x,int means,int y)
{
    int *eq=player[x].equipment,&hp=player[y].hp,cloth=player[y].equipment[0];
    if(means==0)
    {
        if(no_clothing(y)) hp-=eq[1]*2;
        else hp-=eq[1]/cloth;
        if(player[x].role==9) player[x].hp=min(player[x].hp+1,10);
        check(x,y);
    }
    if(means==1)
    {
        if(no_clothing(y)) hp-=eq[2]*4;
        else hp-=eq[2]*3/cloth;
        move(y,8);
        check(x,y);
    }
    if(means==2)
    {
        hp-=eq[4];
        check(x,y);
    }
    if(means==3)
    {
        hp-=eq[5]*2;
        check(x,y);
    }
    if(means==4)
    {
        hp-=eq[6]*3;
        check(x,y);
    }
    if(means==5)
    {
        if(no_clothing(y)) hp-=eq[7]*2;
        else hp-=eq[7]/cloth;
        eq[8]--;
        check(x,y);
    }
    if(means==6)
    {
        position[y].item[4]+=eq[9];
        eq[10]--;
    }
    if(means==7)
    {
        position[player[x].position].item[person[1]==x]++;
        eq[11]--;
    }
    if(means==8)
    {
        hp-=eq[12];
        rand_to_go(y);
        check(x,y);
    }
    if(means==9)
    {
        hp-=eq[13];
        rand_to_go(y);
        check(x,y);
    }
    if(means==10)
    {
        hp-=eq[14]*2;
        rand_to_go(y);
        check(x,y);
    }
    if(means==11)
    {
        player[x].hp=min(player[x].hp+1,10);
    }
    if(means==12)
    {
        position[y].item[2]++;
    }
    if(means==13)
    {
        int tmp=person[1]==x;
        for(int i=0;i<n;i++)
            if(!player[i].die)
                player[i].hp-=position[player[i].position].item[tmp],check(x,i);
        for(int i=0;i<=8;i++)
            position[i].item[tmp]=0;
    }
    rem[x]--;
}
void Game::round_over()
{
    for(int i=0;i<n;i++)
        if(!player[i].die)
            player[i].hp-=position[player[i].position].item[5]*2-position[player[i].position].item[3],check(i);
    for(int i=0;i<=8;i++)
    {
        position[i].item[5]=position[i].item[4];
        position[i].item[3]=position[i].item[2];
        position[i].item[2]=position[i].item[4]=0;
    }
}
int Game::game_over() //-1 没结束 -2 没有赢家 否则返回赢家
{
    int winner=-1;
    for(int i=0;i<n;i++)
        if(!player[i].die)
            if(~winner&&winner!=player[i].team) return -1;
            else winner=player[i].team;
    if(~winner) return winner;
    else return -2;
}
void Game::click_guess(int x)//点击石头剪刀布中的哪个按钮
{
    information[0]=5;
    information[1]=myself;
    information[2]=x;
    send(information);
    hide_button_guess();
}
void Game::click_move()//点击移动按钮
{
    information[0]=1;
    information[1]=myself;
    hide_button_action();
    show_highlight_position_move(where_to_move(myself));
    show_button_back();
}
void Game::click_move_where(int x)//点击移动并选定位置
{
    information[2]=x;
    hide_highlight_position_move();
    if(player[myself].role!=7) send(information);
    else show_highlight_player_move(who_to_touch_plus(myself));
}
void Game::click_move_where_who(int x)//胖子点击移动并抱人
{
    information[3]=x;
    hide_highlight_player_move();
    send(information);
}
void Game::click_buy()//点击购买按钮
{
    information[0]=2;
    information[1]=myself;
    hide_button_action();
    thing.clear();
    for(int i=0;i<14;i++) if(rem[myself]>=cost[i]&&player[myself].right[i]) thing.push_back(i);
    show_button_buy_thing();
    show_button_back();
}
void Game::click_buy_what(int x)//点击购买并选定物品
{
    information[2]=x;
    send(information);
    hide_button_buy_thing();
}
void Game::click_rob()//点击抢夺按钮
{
    information[0]=3;
    information[1]=myself;
    hide_button_action();
    show_highlight_player_rob(who_to_touch(myself));
    show_button_back();
}
void Game::click_rob_who(int x)//点击抢夺并选定对象
{
    information[2]=x;
    hide_highlight_player_rob();
    thing.clear();
    if(player[x].role!=7&&player[x].equipment[0]||player[x].equipment[0]>=2) thing.push_back(0);
    for(int i=1;i<15;i++) if(player[x].equipment[i]) thing.push_back(i);
    show_button_rob_thing();
}
void Game::click_rob_who_what(int x)//点击抢夺选定对象后选择物品
{
    information[3]=x;
    hide_button_rob_thing();
    send(information);
}
void Game::click_attack()//点击攻击 0：刀 1：马 2：铜拳套 3：银拳套 4：金拳套 5：箭 6：炮弹 7：埋雷 8：铜腰带 9：银腰带 10：金腰带 11:法师回血 12：法师魔法 13 雷引爆
{
    information[0]=4;
    information[1]=myself;
    hide_button_action();
    thing.clear();
    int *eq=player[myself].equipment,ro=player[myself].role;
    if(eq[1]&&ro!=2&&ro!=8) thing.push_back(0);
    if(eq[2]&&player[myself].position!=8&&ro!=1&&ro!=2&&ro!=7&&ro!=8) thing.push_back(1);
    if(eq[4]&&ro==2) thing.push_back(2);
    if(eq[5]&&ro==2) thing.push_back(3);
    if(eq[6]&&ro==2) thing.push_back(4);
    if(eq[7]&&eq[8]&&ro==4) thing.push_back(5);
    if(eq[9]&&eq[10]&&ro==5) thing.push_back(6);
    if(eq[11]&&ro==6) thing.push_back(7);
    if(eq[12]&&ro==8) thing.push_back(8);
    if(eq[13]&&ro==8) thing.push_back(9);
    if(eq[14]&&ro==8) thing.push_back(10);
    if(ro==3) thing.push_back(11),thing.push_back(12);
    if(ro==6) thing.push_back(13);
    show_button_attack_thing();
    show_button_back();
}
void Game::click_attack_what(int x)//点击攻击并选择方式
{
    information[2]=x;
    hide_button_attack_thing();
    if(x==7||x==11||x==13)
    {
        send(information);
        return;
    }
    if(x==0||x==1||x==2||x==3||x==4||x==8||x==10) show_highlight_player_attack(who_to_touch(myself));
    if(x==5||x==9)
    {
        bitset<8> flag;flag.set();
        show_highlight_player_attack(flag);
    }
    if(x==6||x==12)
    {
        bitset<9> flag;flag.set();
        show_highlight_position_attack(flag);
    }
}
void Game::click_attack_what_who(int y)//点击攻击并选择方式和对象
{
        information[3]=y;
        int x=information[2];
        if(x==0||x==1||x==2||x==3||x==4||x==8||x==10) hide_highlight_player_attack();
        if(x==5||x==9) hide_highlight_player_attack();
        if(x==6||x==12) hide_highlight_position_attack();
        send(information);
}
void Game::game_start()
{
        information.resize(4);
        for(int i=0;i<n;i++) tmp[i]=0;
        action_list.clear();
        if(player[myself].die==0)
            show_button_guess();
        stop=0;
        for(int i=0;i<n;i++)stop+=!player[i].die;
}
void Game::game_start_single()
{
        hide_button_guess();
        hide_button_back();
        hide_highlight_position_move();
        hide_highlight_player_move();
        hide_highlight_player_rob();
        hide_button_buy_thing();
        hide_button_rob_thing();
        hide_button_attack_thing();
        hide_highlight_position_attack();
        hide_highlight_player_attack();
        person[0]=person[1]=-1;
        for(int i=0;i<n;i++)
            for(int j=0;j<player[i].name.size();j++)
            if(player[i].name[j]<=10)
                player[i].name.resize(j);
        for(int i=0;i<n;i++)
        {
            player[i].hp=10;
            player[i].position=i;
            player[i].team=i;
            player[i].die=0;
            int *eq=player[i].equipment,*ri=player[i].right;
            memset(eq,0,sizeof(player[i].equipment));
            memset(ri,0,sizeof(player[i].right));
            if(player[i].role==1) eq[0]=ri[0]=ri[2]=1;
            else if(player[i].role==2) ri[3]=ri[4]=ri[5]=1;
            else if(player[i].role==3) eq[0]=ri[0]=ri[1]=1;
            else if(player[i].role==4) eq[0]=ri[0]=ri[1]=ri[6]=1,ri[7]=-1;
            else if(player[i].role==5) eq[0]=ri[0]=ri[1]=ri[8]=1,ri[9]=-1;
            else if(player[i].role==6)
            {
                eq[0]=ri[0]=ri[1]=1,ri[10]=-1;
                if(~person[0]) person[1]=i;
                else person[0]=i;
            }
            else if(player[i].role==7) eq[0]=2,ri[0]=1;
            else if(player[i].role==8) ri[11]=ri[12]=ri[13]=1;
            else if(player[i].role==9) eq[0]=ri[0]=ri[1]=1;
        }
        for(int i=0;i<=8;i++) memset(position[i].item,0,sizeof(position[i].item));
        action_list.clear();
        for(int i=0;i<n;++i) action_list.push_back(i);
        print();
        game_start();
}
/*
void Game::game_start_team(const vector<string> &name,const vector<int> &role,const vector<int> &team)
{
        n=name.size();
        person[0]=person[1]=-1;
        for(int i=0;i<n;i++)
        {
            player[i].name=name[i];
            player[i].hp=10;
            player[i].role=role[i];
            player[i].position=i;
            player[i].team=team[i];
            player[i].die=0;
            int *eq=player[i].equipment,*ri=player[i].right;
            memset(eq,0,sizeof(player[i].equipment));
            memset(ri,0,sizeof(player[i].right));
            if(role[i]==1) eq[0]=ri[0]=ri[2]=1;
            else if(role[i]==2) ri[3]=ri[4]=ri[5]=1;
            else if(role[i]==3) eq[0]=ri[0]=ri[1]=1;
            else if(role[i]==4) eq[0]=ri[0]=ri[1]=ri[6]=1,ri[7]=-1;
            else if(role[i]==5) eq[0]=ri[0]=ri[1]=ri[8]=1,ri[9]=-1;
            else if(role[i]==6)
            {
                eq[0]=ri[0]=ri[1]=1,ri[10]=-1;
                if(~person[0]) person[1]=i;
                else person[0]=i;
            }
            else if(role[i]==7) eq[0]=2,ri[0]=1;
            else if(role[i]==8) ri[11]=ri[12]=ri[13]=1;
            else if(role[i]==9) eq[0]=ri[0]=ri[1]=1;
        }
        for(int i=0;i<=8;i++) memset(position[i].item,0,sizeof(position[i].item));
        game_start();
}
*/
void Game::send(string s)//首位为 1 表示移动 2 表示购买 3 表示抢夺 4 表示攻击 5 表示石头剪刀布处理
{
        qDebug()<<s+"+2";
        for(int i=1;i<s.size();i++)
            if(s[i]==0) s[i]='&';
    client->socket->write((s+"+2").c_str());
}
void Game::next()
{
        if(now_person==myself) hide_button_back();
        print();
        int winner=game_over();
        if(winner!=-1)
        {
            print_winner(winner);
            return;
        }
        if(rem[now_person])
        {
            if(now_person==myself) show_button_action();
        }
        else
        {
            do
            {
                n_person++;
                if(n_person==action_list.size()||!rem[action_list[n_person]])
                {
                    round_over();
                    now_person=-1;
                    print();
                    int winner=game_over();
                    if(winner!=-1)
                    {
                        print_winner(winner);
                        return;
                    }
                    game_start();
                    return;
                }
                now_person=action_list[n_person];
            }while(player[now_person].die);
            print();
            if(now_person==myself) show_button_action();
        }
}
unsigned long long rnd() {
        static unsigned long long m = 123;
        m ^= m << 12;
        m ^= m >> 25;
        m ^= m << 27;
        return m;
}
void Game::receive(string s)//首位为 1 表示移动 2 表示购买 3 表示抢夺 4 表示攻击 5 表示石头剪刀布处理
{
    for(int i=1;i<s.size();i++)
            if(s[i]=='&') s[i]=0;
    if(s[0]==1)
    {
        if(player[s[1]].role!=7) move(s[1],s[2]);
        else move_plus(s[1],s[2],s[3]);
        rem[s[1]]--;
        next();
    }
    if(s[0]==2)
    {
        buy(s[1],s[2]);
        next();
    }
    if(s[0]==3)
    {
        rob(s[1],s[2],s[3]);
        next();
    }
    if(s[0]==4)
    {
        attack(s[1],s[2],s[3]);
        next();
    }
    if(s[0]==5)
    {
        tmp[s[1]]=s[2];
        stop--;
        if(!stop)
        {
                for(int i=0;i<n;i++)
                {
                    rem[i]=0;
                    if(player[i].die) continue;
                    for(int j=0;j<n;j++)
                        if(!player[j].die&&(tmp[i]-tmp[j]+3)%3==1)
                            rem[i]++;
                }
                for(int i=0;i<n;i++)
                if(rem[i]) action_list.push_back(i);
                for (int i=0;i<action_list.size();++i) swap(action_list[i],action_list[rnd()%(i+1)]);
                for(int i=0;i<n;i++)
                if(!player[i].die&&!rem[i]) action_list.push_back(i);
                n_person=0;
                now_person = action_list[n_person];
                if(!rem[now_person])
                {
                    round_over();
                    now_person=-1;
                    print();
                    int winner=game_over();
                    if(winner!=-1)
                    {
                        print_winner(winner);
                        return;
                    }
                    game_start();
                    return;
                }
                print();
                if(now_person==myself) show_button_action();
        }
    }
    if(s[0]==6)//选英雄
    {
        player[s[1]].role = s[2];
        c[s[2]]--;
        ++readycount;
        information[0]=7;
        information[1]=myself;
        information.resize(2);
        for(int i=0;i<name.size();i++)information.push_back(name.toUtf8().data()[i]);
        send(information);
        if (readycount == n)
        {
            if(n>0)fms.fm8->ui->btn0->show(),move(0,0);else fms.fm8->ui->btn0->close();
            if(n>1)fms.fm8->ui->btn1->show(),move(1,1);else fms.fm8->ui->btn1->close();
            if(n>2)fms.fm8->ui->btn2->show(),move(2,2);else fms.fm8->ui->btn2->close();
            if(n>3)fms.fm8->ui->btn3->show(),move(3,3);else fms.fm8->ui->btn3->close();
            if(n>4)fms.fm8->ui->btn4->show(),move(4,4);else fms.fm8->ui->btn4->close();
            if(n>5)fms.fm8->ui->btn5->show(),move(5,5);else fms.fm8->ui->btn5->close();
            if(n>6)fms.fm8->ui->btn6->show(),move(6,6);else fms.fm8->ui->btn6->close();
            if(n>7)fms.fm8->ui->btn7->show(),move(7,7);else fms.fm8->ui->btn7->close();
            fms.fm7->close();
            fms.fm8->show();
            game_start_single();
        }
    }
    if(s[0]==7)//确定名字
    {
        player[s[1]].name=s.substr(2,s.size());
    }
    if(s[0]==8)//加入显示名字
    {
        n=s[1];
        fms.fm5->ui->label->setText(QString::fromStdString(s.substr(2, s.length())));
    }
    if(s[0]==9)//游戏开始
    {
        fms.fm7->show();
        fms.fm5->hide();
    }
    if(s[0]==10)//确定自己的id
    {
        myself=s[1];
    }
}
void Game::show_button_guess()//展示剪刀石头布按钮
{
    fms.fm8->ui->stackedWidget->setCurrentIndex(2);
}
void Game::hide_button_guess()//隐藏剪刀石头布按钮
{
    fms.fm8->ui->stackedWidget->setCurrentIndex(5);
}
void Game::show_button_action()//展示移动购买抢夺攻击按钮
{
    fms.fm8->ui->stackedWidget->setCurrentIndex(6);

}
void Game::hide_button_action()//隐藏移动购买抢夺攻击按钮
{
    fms.fm8->ui->stackedWidget->setCurrentIndex(5);


}
void Game::print()//打印状态栏 打印时按照action_list顺序打印，并检查该人是否死亡，若!player[x].die，则打印该人状态
{
    static vector<QLabel*> q;
    for (auto i : q) delete(i);
    q.clear();
    static QString role[]={"","外星人","拳击手","法师","弓箭手","炮手","雷兵","胖子","气功大师","吸血鬼"};
    static QString eq[]={"clothing","sword","horse","pearl","stoneaxe","ironaxe","diamondaxe","bow","arrow","cannon","cannonball","mine","stonestaff","ironstaff","diamondstaff"};
    vector<int> v;
    for (int x : action_list)
        if (!player[x].die)
            v.push_back(x);
    int x, l = v.size();
    for (int i = 0; i < 9; ++i) {
        if (position[i].item[0] + position[i].item[1]) {
            QImage img;
            img.load(":/res_items/mine.png");
            QLabel *u = new QLabel(fms.fm8);
            q.push_back(u);
            u->setGeometry(movexy[i][0]-10,movexy[i][1]-30,30,30);
            u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
            QLabel *v = new QLabel(fms.fm8);
            q.push_back(v);
            v->move(movexy[i][0]+20,movexy[i][1]-20);
            v->setText(QString("×%1").arg(position[i].item[0] + position[i].item[1]));
            qDebug() << v;
            v->show();
            u->show();
        }
        if (position[i].item[2] + position[i].item[3]) {
            QImage img;
            img.load(":/res_items/potion2.png");
            QLabel *u = new QLabel(fms.fm8);
            q.push_back(u);
            u->setGeometry(movexy[i][0]+40,movexy[i][1]-25,30,30);
            u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
            QLabel *v = new QLabel(fms.fm8);
            q.push_back(v);
            v->move(movexy[i][0]+20+40,movexy[i][1]-20);
            v->setText(QString("×%1").arg(position[i].item[2] + position[i].item[3]));
            qDebug() << v;
            v->show();
            u->show();
        }
        if (position[i].item[4] + position[i].item[5]) {
            QImage img;
            img.load(":/res_items/lightning.png");
            QLabel *u = new QLabel(fms.fm8);
            q.push_back(u);
            u->setGeometry(movexy[i][0]+80,movexy[i][1]-30,30,30);
            u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
            QLabel *v = new QLabel(fms.fm8);
            q.push_back(v);
            v->move(movexy[i][0]+100,movexy[i][1]-20);
            v->setText(QString("×%1").arg(position[i].item[4] + position[i].item[5]));
            qDebug() << v;
            v->show();
            u->show();
        }
    }
    if (l > 0) {
        x = v[0];
        fms.fm8->ui->hp_0->show();
        fms.fm8->ui->hp_0->setText(QString("%1").arg(player[x].hp));
        fms.fm8->ui->rem_0->show();
        fms.fm8->ui->rem_0->setText(QString("%1").arg(rem[x]));
        fms.fm8->ui->icon_0->show();
        QImage img;
        if (x == now_person)
            img.load(QString(":/res_items/%1g.png").arg(x));
        else
            img.load(QString(":/res_items/%1.png").arg(x));
        fms.fm8->ui->icon_0->setGeometry(666, 2, 45, 45);
        fms.fm8->ui->icon_0->setPixmap(QPixmap::fromImage(img.scaled(45,45,Qt::KeepAspectRatio)));
        fms.fm8->ui->name_0->show();
        fms.fm8->ui->name_0->setText(QString::fromStdString(player[x].name));
        fms.fm8->ui->role_0->show();
        fms.fm8->ui->role_0->setText(role[player[x].role]);
        int ct = 0;
        for (int i = 0; i < 15; ++i)
            if (player[x].equipment[i] > 0) {
                QLabel *u = new QLabel(fms.fm8);
                q.push_back(u);
                QImage img;
                img.load(QString(":/res_items/%1.png").arg(eq[i]));
                u->setGeometry(739+ct%8*37,2+ct/8*37,30,30);
                u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
                QLabel *v = new QLabel(fms.fm8);
                q.push_back(v);
                v->move(739+ct%8*37+20,2+ct/8*37+20);
                v->setText(QString("×%1").arg(player[x].equipment[i]));
                u->show();
                v->show();
                ++ct;
            }
    } else {
        fms.fm8->ui->hp_0->close();
        fms.fm8->ui->rem_0->close();
        fms.fm8->ui->icon_0->close();
        fms.fm8->ui->name_0->close();
        fms.fm8->ui->role_0->close();
    }
    if (l > 1) {
        x = v[1];
        fms.fm8->ui->hp_1->show();
        fms.fm8->ui->hp_1->setText(QString("%1").arg(player[x].hp));
        fms.fm8->ui->rem_1->show();
        fms.fm8->ui->rem_1->setText(QString("%1").arg(rem[x]));
        fms.fm8->ui->icon_1->show();
        QImage img;
        if (x == now_person)
            img.load(QString(":/res_items/%1g.png").arg(x));
        else
            img.load(QString(":/res_items/%1.png").arg(x));
        fms.fm8->ui->icon_1->setGeometry(666, 2+74, 45, 45);
        fms.fm8->ui->icon_1->setPixmap(QPixmap::fromImage(img.scaled(45,45,Qt::KeepAspectRatio)));
        fms.fm8->ui->name_1->show();
        fms.fm8->ui->name_1->setText(QString::fromStdString(player[x].name));
        fms.fm8->ui->role_1->show();
        fms.fm8->ui->role_1->setText(role[player[x].role]);
        int ct = 0;
        for (int i = 0; i < 15; ++i)
            if (player[x].equipment[i] > 0) {
                QLabel *u = new QLabel(fms.fm8);
                q.push_back(u);
                QImage img;
                img.load(QString(":/res_items/%1.png").arg(eq[i]));
                u->setGeometry(739+ct%8*37,2+74+ct/8*37,30,30);
                u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
                QLabel *v = new QLabel(fms.fm8);
                q.push_back(v);
                v->move(739+ct%8*37+20,2+74+ct/8*37+20);
                v->setText(QString("×%1").arg(player[x].equipment[i]));
                u->show();
                v->show();
                ++ct;
            }
    } else {
        fms.fm8->ui->hp_1->close();
        fms.fm8->ui->rem_1->close();
        fms.fm8->ui->icon_1->close();
        fms.fm8->ui->name_1->close();
        fms.fm8->ui->role_1->close();
    }
    if (l > 2) {
        x = v[2];
        fms.fm8->ui->hp_2->show();
        fms.fm8->ui->hp_2->setText(QString("%1").arg(player[x].hp));
        fms.fm8->ui->rem_2->show();
        fms.fm8->ui->rem_2->setText(QString("%1").arg(rem[x]));
        fms.fm8->ui->icon_2->show();
        QImage img;
        if (x == now_person)
            img.load(QString(":/res_items/%1g.png").arg(x));
        else
            img.load(QString(":/res_items/%1.png").arg(x));
        fms.fm8->ui->icon_2->setGeometry(666, 2+74*2, 45, 45);
        fms.fm8->ui->icon_2->setPixmap(QPixmap::fromImage(img.scaled(45,45,Qt::KeepAspectRatio)));
        fms.fm8->ui->name_2->show();
        fms.fm8->ui->name_2->setText(QString::fromStdString(player[x].name));
        fms.fm8->ui->role_2->show();
        fms.fm8->ui->role_2->setText(role[player[x].role]);
        int ct = 0;
        for (int i = 0; i < 15; ++i)
            if (player[x].equipment[i] > 0) {
                QLabel *u = new QLabel(fms.fm8);
                q.push_back(u);
                QImage img;
                img.load(QString(":/res_items/%1.png").arg(eq[i]));
                u->setGeometry(739+ct%8*37,2+74*2+ct/8*37,30,30);
                u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
                QLabel *v = new QLabel(fms.fm8);
                q.push_back(v);
                v->move(739+ct%8*37+20,2+74*2+ct/8*37+20);
                v->setText(QString("×%1").arg(player[x].equipment[i]));
                u->show();
                v->show();
                ++ct;
            }
    } else {
        fms.fm8->ui->hp_2->close();
        fms.fm8->ui->rem_2->close();
        fms.fm8->ui->icon_2->close();
        fms.fm8->ui->name_2->close();
        fms.fm8->ui->role_2->close();
    }
    if (l > 3) {
        x = v[3];
        fms.fm8->ui->hp_3->show();
        fms.fm8->ui->hp_3->setText(QString("%1").arg(player[x].hp));
        fms.fm8->ui->rem_3->show();
        fms.fm8->ui->rem_3->setText(QString("%1").arg(rem[x]));
        fms.fm8->ui->icon_3->show();
        QImage img;
        if (x == now_person)
            img.load(QString(":/res_items/%1g.png").arg(x));
        else
            img.load(QString(":/res_items/%1.png").arg(x));
        fms.fm8->ui->icon_3->setGeometry(666, 2+74*3, 45, 45);
        fms.fm8->ui->icon_3->setPixmap(QPixmap::fromImage(img.scaled(45,45,Qt::KeepAspectRatio)));
        fms.fm8->ui->name_3->show();
        fms.fm8->ui->name_3->setText(QString::fromStdString(player[x].name));
        fms.fm8->ui->role_3->show();
        fms.fm8->ui->role_3->setText(role[player[x].role]);
        int ct = 0;
        for (int i = 0; i < 15; ++i)
            if (player[x].equipment[i] > 0) {
                QLabel *u = new QLabel(fms.fm8);
                q.push_back(u);
                QImage img;
                img.load(QString(":/res_items/%1.png").arg(eq[i]));
                u->setGeometry(739+ct%8*37,2+74*3+ct/8*37,30,30);
                u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
                QLabel *v = new QLabel(fms.fm8);
                q.push_back(v);
                v->move(739+ct%8*37+20,2+74*3+ct/8*37+20);
                v->setText(QString("×%1").arg(player[x].equipment[i]));
                u->show();
                v->show();
                ++ct;
            }
    } else {
        fms.fm8->ui->hp_3->close();
        fms.fm8->ui->rem_3->close();
        fms.fm8->ui->icon_3->close();
        fms.fm8->ui->name_3->close();
        fms.fm8->ui->role_3->close();
    }
    if (l > 4) {
        x = v[4];
        fms.fm8->ui->hp_4->show();
        fms.fm8->ui->hp_4->setText(QString("%1").arg(player[x].hp));
        fms.fm8->ui->rem_4->show();
        fms.fm8->ui->rem_4->setText(QString("%1").arg(rem[x]));
        fms.fm8->ui->icon_4->show();
        QImage img;
        if (x == now_person)
            img.load(QString(":/res_items/%1g.png").arg(x));
        else
            img.load(QString(":/res_items/%1.png").arg(x));
        fms.fm8->ui->icon_4->setGeometry(666, 2+74*4, 45, 45);
        fms.fm8->ui->icon_4->setPixmap(QPixmap::fromImage(img.scaled(45,45,Qt::KeepAspectRatio)));
        fms.fm8->ui->name_4->show();
        fms.fm8->ui->name_4->setText(QString::fromStdString(player[x].name));
        fms.fm8->ui->role_4->show();
        fms.fm8->ui->role_4->setText(role[player[x].role]);
        int ct = 0;
        for (int i = 0; i < 15; ++i)
            if (player[x].equipment[i] > 0) {
                QLabel *u = new QLabel(fms.fm8);
                q.push_back(u);
                QImage img;
                img.load(QString(":/res_items/%1.png").arg(eq[i]));
                u->setGeometry(739+ct%8*37,2+74*4+ct/8*37,30,30);
                u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
                QLabel *v = new QLabel(fms.fm8);
                q.push_back(v);
                v->move(739+ct%8*37+20,2+74*4+ct/8*37+20);
                v->setText(QString("×%1").arg(player[x].equipment[i]));
                u->show();
                v->show();
                ++ct;
            }
    } else {
        fms.fm8->ui->hp_4->close();
        fms.fm8->ui->rem_4->close();
        fms.fm8->ui->icon_4->close();
        fms.fm8->ui->name_4->close();
        fms.fm8->ui->role_4->close();
    }
    if (l > 5) {
        x = v[5];
        fms.fm8->ui->hp_5->show();
        fms.fm8->ui->hp_5->setText(QString("%1").arg(player[x].hp));
        fms.fm8->ui->rem_5->show();
        fms.fm8->ui->rem_5->setText(QString("%1").arg(rem[x]));
        fms.fm8->ui->icon_5->show();
        QImage img;
        if (x == now_person)
            img.load(QString(":/res_items/%1g.png").arg(x));
        else
            img.load(QString(":/res_items/%1.png").arg(x));
        fms.fm8->ui->icon_5->setGeometry(666, 2+74*5, 45, 45);
        fms.fm8->ui->icon_5->setPixmap(QPixmap::fromImage(img.scaled(45,45,Qt::KeepAspectRatio)));
        fms.fm8->ui->name_5->show();
        fms.fm8->ui->name_5->setText(QString::fromStdString(player[x].name));
        fms.fm8->ui->role_5->show();
        fms.fm8->ui->role_5->setText(role[player[x].role]);
        int ct = 0;
        for (int i = 0; i < 15; ++i)
            if (player[x].equipment[i] > 0) {
                QLabel *u = new QLabel(fms.fm8);
                q.push_back(u);
                QImage img;
                img.load(QString(":/res_items/%1.png").arg(eq[i]));
                u->setGeometry(739+ct%8*37,2+74*5+ct/8*37,30,30);
                u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
                QLabel *v = new QLabel(fms.fm8);
                q.push_back(v);
                v->move(739+ct%8*37+20,2+74*5+ct/8*37+20);
                v->setText(QString("×%1").arg(player[x].equipment[i]));
                u->show();
                v->show();
                ++ct;
            }
    } else {
        fms.fm8->ui->hp_5->close();
        fms.fm8->ui->rem_5->close();
        fms.fm8->ui->icon_5->close();
        fms.fm8->ui->name_5->close();
        fms.fm8->ui->role_5->close();
    }
    if (l > 6) {
        x = v[6];
        fms.fm8->ui->hp_6->show();
        fms.fm8->ui->hp_6->setText(QString("%1").arg(player[x].hp));
        fms.fm8->ui->rem_6->show();
        fms.fm8->ui->rem_6->setText(QString("%1").arg(rem[x]));
        fms.fm8->ui->icon_6->show();
        QImage img;
        if (x == now_person)
            img.load(QString(":/res_items/%1g.png").arg(x));
        else
            img.load(QString(":/res_items/%1.png").arg(x));
        fms.fm8->ui->icon_6->setGeometry(666, 2+74*6, 45, 45);
        fms.fm8->ui->icon_6->setPixmap(QPixmap::fromImage(img.scaled(45,45,Qt::KeepAspectRatio)));
        fms.fm8->ui->name_6->show();
        fms.fm8->ui->name_6->setText(QString::fromStdString(player[x].name));
        fms.fm8->ui->role_6->show();
        fms.fm8->ui->role_6->setText(role[player[x].role]);
        int ct = 0;
        for (int i = 0; i < 15; ++i)
            if (player[x].equipment[i] > 0) {
                QLabel *u = new QLabel(fms.fm8);
                q.push_back(u);
                QImage img;
                img.load(QString(":/res_items/%1.png").arg(eq[i]));
                u->setGeometry(739+ct%8*37,2+74*6+ct/8*37,30,30);
                u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
                QLabel *v = new QLabel(fms.fm8);
                q.push_back(v);
                v->move(739+ct%8*37+20,2+74*6+ct/8*37+20);
                v->setText(QString("×%1").arg(player[x].equipment[i]));
                u->show();
                v->show();
                ++ct;
            }
    } else {
        fms.fm8->ui->hp_6->close();
        fms.fm8->ui->rem_6->close();
        fms.fm8->ui->icon_6->close();
        fms.fm8->ui->name_6->close();
        fms.fm8->ui->role_6->close();
    }
    if (l > 7) {
        x = v[7];
        fms.fm8->ui->hp_7->show();
        fms.fm8->ui->hp_7->setText(QString("%1").arg(player[x].hp));
        fms.fm8->ui->rem_7->show();
        fms.fm8->ui->rem_7->setText(QString("%1").arg(rem[x]));
        fms.fm8->ui->icon_7->show();
        QImage img;
        if (x == now_person)
            img.load(QString(":/res_items/%1g.png").arg(x));
        else
            img.load(QString(":/res_items/%1.png").arg(x));
        fms.fm8->ui->icon_7->setGeometry(666, 2+74*7, 45, 45);
        fms.fm8->ui->icon_7->setPixmap(QPixmap::fromImage(img.scaled(45,45,Qt::KeepAspectRatio)));
        fms.fm8->ui->name_7->show();
        fms.fm8->ui->name_7->setText(QString::fromStdString(player[x].name));
        fms.fm8->ui->role_7->show();
        fms.fm8->ui->role_7->setText(role[player[x].role]);
        int ct = 0;
        for (int i = 0; i < 15; ++i)
            if (player[x].equipment[i] > 0) {
                QLabel *u = new QLabel(fms.fm8);
                q.push_back(u);
                QImage img;
                img.load(QString(":/res_items/%1.png").arg(eq[i]));
                u->setGeometry(739+ct%8*37,2+74*7+ct/8*37,30,30);
                u->setPixmap(QPixmap::fromImage(img.scaled(30,30,Qt::KeepAspectRatio)));
                QLabel *v = new QLabel(fms.fm8);
                q.push_back(v);
                v->move(739+ct%8*37+20,2+74*7+ct/8*37+20);
                v->setText(QString("×%1").arg(player[x].equipment[i]));
                u->show();
                v->show();
                ++ct;
            }
    } else {
        fms.fm8->ui->hp_7->close();
        fms.fm8->ui->rem_7->close();
        fms.fm8->ui->icon_7->close();
        fms.fm8->ui->name_7->close();
        fms.fm8->ui->role_7->close();
    }
}
void Game::show_highlight_position_move(bitset<9> flag)//显示移动下属位置高亮
{
    fms.fm8->ui->btn_mv_0->show();
    fms.fm8->ui->btn_mv_1->show();
    fms.fm8->ui->btn_mv_2->show();
    fms.fm8->ui->btn_mv_3->show();
    fms.fm8->ui->btn_mv_4->show();
    fms.fm8->ui->btn_mv_5->show();
    fms.fm8->ui->btn_mv_6->show();
    fms.fm8->ui->btn_mv_7->show();
    fms.fm8->ui->btn_mv_8->show();

    fms.fm8->ui->btn_mv_0->setEnabled(flag[0]);
    fms.fm8->ui->btn_mv_1->setEnabled(flag[1]);
    fms.fm8->ui->btn_mv_2->setEnabled(flag[2]);
    fms.fm8->ui->btn_mv_3->setEnabled(flag[3]);
    fms.fm8->ui->btn_mv_4->setEnabled(flag[4]);
    fms.fm8->ui->btn_mv_5->setEnabled(flag[5]);
    fms.fm8->ui->btn_mv_6->setEnabled(flag[6]);
    fms.fm8->ui->btn_mv_7->setEnabled(flag[7]);
    fms.fm8->ui->btn_mv_8->setEnabled(flag[8]);

    QPixmap pixmap0(QString(":/res_items/%1").arg(flag[0]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_0->resize(pixmap0.size());
    fms.fm8->ui->btn_mv_0->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[0]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap1(QString(":/res_items/%1").arg(flag[1]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_1->resize(pixmap1.size());
    fms.fm8->ui->btn_mv_1->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[1]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap2(QString(":/res_items/%1").arg(flag[2]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_2->resize(pixmap2.size());
    fms.fm8->ui->btn_mv_2->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[2]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap3(QString(":/res_items/%1").arg(flag[3]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_3->resize(pixmap3.size());
    fms.fm8->ui->btn_mv_3->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[3]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap4(QString(":/res_items/%1").arg(flag[4]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_4->resize(pixmap4.size());
    fms.fm8->ui->btn_mv_4->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[4]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap5(QString(":/res_items/%1").arg(flag[5]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_5->resize(pixmap5.size());
    fms.fm8->ui->btn_mv_5->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[5]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap6(QString(":/res_items/%1").arg(flag[6]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_6->resize(pixmap6.size());
    fms.fm8->ui->btn_mv_6->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[6]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap7(QString(":/res_items/%1").arg(flag[7]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_7->resize(pixmap7.size());
    fms.fm8->ui->btn_mv_7->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[7]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap8(QString(":/res_items/%1").arg(flag[8]?"btn_green_8.png":"btn_red_8.png"));
    fms.fm8->ui->btn_mv_8->resize(pixmap8.size());
    fms.fm8->ui->btn_mv_8->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[8]?"btn_green_8.png":"btn_red_8.png"));

}
void Game::hide_highlight_position_move()//隐藏移动下属位置高亮
{
    fms.fm8->ui->btn_mv_0->close();
    fms.fm8->ui->btn_mv_1->close();
    fms.fm8->ui->btn_mv_2->close();
    fms.fm8->ui->btn_mv_3->close();
    fms.fm8->ui->btn_mv_4->close();
    fms.fm8->ui->btn_mv_5->close();
    fms.fm8->ui->btn_mv_6->close();
    fms.fm8->ui->btn_mv_7->close();
    fms.fm8->ui->btn_mv_8->close();

}
void Game::show_highlight_player_move(bitset<8> flag)//显示胖子移动带人的高亮
{
    fms.fm8->ui->btn0->setEnabled(flag[0]);
    fms.fm8->ui->btn1->setEnabled(flag[1]);
    fms.fm8->ui->btn2->setEnabled(flag[2]);
    fms.fm8->ui->btn3->setEnabled(flag[3]);
    fms.fm8->ui->btn4->setEnabled(flag[4]);
    fms.fm8->ui->btn5->setEnabled(flag[5]);
    fms.fm8->ui->btn6->setEnabled(flag[6]);
    fms.fm8->ui->btn7->setEnabled(flag[7]);

    QPixmap pixmap0(QString(":/res_items/%1").arg(flag[0]?"0g.png":"0r.png"));
    fms.fm8->ui->btn0->setMask(QBitmap(pixmap0.mask()));
    fms.fm8->ui->btn0->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[0]?"0g.png":"0r.png"));
    QPixmap pixmap1(QString(":/res_items/%1").arg(flag[1]?"1g.png":"1r.png"));
    fms.fm8->ui->btn1->setMask(QBitmap(pixmap1.mask()));
    fms.fm8->ui->btn1->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[1]?"1g.png":"1r.png"));
    QPixmap pixmap2(QString(":/res_items/%1").arg(flag[2]?"2g.png":"2r.png"));
    fms.fm8->ui->btn2->setMask(QBitmap(pixmap2.mask()));
    fms.fm8->ui->btn2->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[2]?"2g.png":"2r.png"));
    QPixmap pixmap3(QString(":/res_items/%1").arg(flag[3]?"3g.png":"3r.png"));
    fms.fm8->ui->btn3->setMask(QBitmap(pixmap3.mask()));
    fms.fm8->ui->btn3->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[3]?"3g.png":"3r.png"));
    QPixmap pixmap4(QString(":/res_items/%1").arg(flag[4]?"4g.png":"4r.png"));
    fms.fm8->ui->btn4->setMask(QBitmap(pixmap4.mask()));
    fms.fm8->ui->btn4->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[4]?"4g.png":"4r.png"));
    QPixmap pixmap5(QString(":/res_items/%1").arg(flag[5]?"5g.png":"5r.png"));
    fms.fm8->ui->btn5->setMask(QBitmap(pixmap5.mask()));
    fms.fm8->ui->btn5->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[5]?"5g.png":"5r.png"));
    QPixmap pixmap6(QString(":/res_items/%1").arg(flag[6]?"6g.png":"6r.png"));
    fms.fm8->ui->btn6->setMask(QBitmap(pixmap6.mask()));
    fms.fm8->ui->btn6->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[6]?"6g.png":"6r.png"));
    QPixmap pixmap7(QString(":/res_items/%1").arg(flag[7]?"7g.png":"7r.png"));
    fms.fm8->ui->btn7->setMask(QBitmap(pixmap7.mask()));
    fms.fm8->ui->btn7->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[7]?"7g.png":"7r.png"));


}
void Game::hide_highlight_player_move()//隐藏胖子移动带人的高亮
{
    fms.fm8->ui->btn0->setEnabled(0);
    fms.fm8->ui->btn1->setEnabled(0);
    fms.fm8->ui->btn2->setEnabled(0);
    fms.fm8->ui->btn3->setEnabled(0);
    fms.fm8->ui->btn4->setEnabled(0);
    fms.fm8->ui->btn5->setEnabled(0);
    fms.fm8->ui->btn6->setEnabled(0);
    fms.fm8->ui->btn7->setEnabled(0);

    QPixmap pixmap0(":/res_items/0.png");
    fms.fm8->ui->btn0->setMask(QBitmap(pixmap0.mask()));
    fms.fm8->ui->btn0->setStyleSheet("QToolButton{border-image: url(:/res_items/0.png);}");
    QPixmap pixmap1(":/res_items/1.png");
    fms.fm8->ui->btn1->setMask(QBitmap(pixmap1.mask()));
    fms.fm8->ui->btn1->setStyleSheet("QToolButton{border-image: url(:/res_items/1.png);}");
    QPixmap pixmap2(":/res_items/2.png");
    fms.fm8->ui->btn2->setMask(QBitmap(pixmap2.mask()));
    fms.fm8->ui->btn2->setStyleSheet("QToolButton{border-image: url(:/res_items/2.png);}");
    QPixmap pixmap3(":/res_items/3.png");
    fms.fm8->ui->btn3->setMask(QBitmap(pixmap3.mask()));
    fms.fm8->ui->btn3->setStyleSheet("QToolButton{border-image: url(:/res_items/3.png);}");
    QPixmap pixmap4(":/res_items/4.png");
    fms.fm8->ui->btn4->setMask(QBitmap(pixmap4.mask()));
    fms.fm8->ui->btn4->setStyleSheet("QToolButton{border-image: url(:/res_items/4.png);}");
    QPixmap pixmap5(":/res_items/5.png");
    fms.fm8->ui->btn5->setMask(QBitmap(pixmap5.mask()));
    fms.fm8->ui->btn5->setStyleSheet("QToolButton{border-image: url(:/res_items/5.png);}");
    QPixmap pixmap6(":/res_items/6.png");
    fms.fm8->ui->btn6->setMask(QBitmap(pixmap6.mask()));
    fms.fm8->ui->btn6->setStyleSheet("QToolButton{border-image: url(:/res_items/6.png);}");
    QPixmap pixmap7(":/res_items/7.png");
    fms.fm8->ui->btn7->setMask(QBitmap(pixmap7.mask()));
    fms.fm8->ui->btn7->setStyleSheet("QToolButton{border-image: url(:/res_items/7.png);}");
}
void Game::show_highlight_player_rob(bitset<8> flag)//显示抢夺下属玩家高亮
{
    fms.fm8->ui->btn0->setEnabled(flag[0]);
    fms.fm8->ui->btn1->setEnabled(flag[1]);
    fms.fm8->ui->btn2->setEnabled(flag[2]);
    fms.fm8->ui->btn3->setEnabled(flag[3]);
    fms.fm8->ui->btn4->setEnabled(flag[4]);
    fms.fm8->ui->btn5->setEnabled(flag[5]);
    fms.fm8->ui->btn6->setEnabled(flag[6]);
    fms.fm8->ui->btn7->setEnabled(flag[7]);

    QPixmap pixmap0(QString(":/res_items/%1").arg(flag[0]?"0g.png":"0r.png"));
    fms.fm8->ui->btn0->setMask(QBitmap(pixmap0.mask()));
    fms.fm8->ui->btn0->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[0]?"0g.png":"0r.png"));
    QPixmap pixmap1(QString(":/res_items/%1").arg(flag[1]?"1g.png":"1r.png"));
    fms.fm8->ui->btn1->setMask(QBitmap(pixmap1.mask()));
    fms.fm8->ui->btn1->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[1]?"1g.png":"1r.png"));
    QPixmap pixmap2(QString(":/res_items/%1").arg(flag[2]?"2g.png":"2r.png"));
    fms.fm8->ui->btn2->setMask(QBitmap(pixmap2.mask()));
    fms.fm8->ui->btn2->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[2]?"2g.png":"2r.png"));
    QPixmap pixmap3(QString(":/res_items/%1").arg(flag[3]?"3g.png":"3r.png"));
    fms.fm8->ui->btn3->setMask(QBitmap(pixmap3.mask()));
    fms.fm8->ui->btn3->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[3]?"3g.png":"3r.png"));
    QPixmap pixmap4(QString(":/res_items/%1").arg(flag[4]?"4g.png":"4r.png"));
    fms.fm8->ui->btn4->setMask(QBitmap(pixmap4.mask()));
    fms.fm8->ui->btn4->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[4]?"4g.png":"4r.png"));
    QPixmap pixmap5(QString(":/res_items/%1").arg(flag[5]?"5g.png":"5r.png"));
    fms.fm8->ui->btn5->setMask(QBitmap(pixmap5.mask()));
    fms.fm8->ui->btn5->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[5]?"5g.png":"5r.png"));
    QPixmap pixmap6(QString(":/res_items/%1").arg(flag[6]?"6g.png":"6r.png"));
    fms.fm8->ui->btn6->setMask(QBitmap(pixmap6.mask()));
    fms.fm8->ui->btn6->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[6]?"6g.png":"6r.png"));
    QPixmap pixmap7(QString(":/res_items/%1").arg(flag[7]?"7g.png":"7r.png"));
    fms.fm8->ui->btn7->setMask(QBitmap(pixmap7.mask()));
    fms.fm8->ui->btn7->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[7]?"7g.png":"7r.png"));


}
void Game::hide_highlight_player_rob()//隐藏抢夺下属玩家高亮
{
    fms.fm8->ui->btn0->setEnabled(0);
    fms.fm8->ui->btn1->setEnabled(0);
    fms.fm8->ui->btn2->setEnabled(0);
    fms.fm8->ui->btn3->setEnabled(0);
    fms.fm8->ui->btn4->setEnabled(0);
    fms.fm8->ui->btn5->setEnabled(0);
    fms.fm8->ui->btn6->setEnabled(0);
    fms.fm8->ui->btn7->setEnabled(0);

    QPixmap pixmap0(":/res_items/0.png");
    fms.fm8->ui->btn0->setMask(QBitmap(pixmap0.mask()));
    fms.fm8->ui->btn0->setStyleSheet("QToolButton{border-image: url(:/res_items/0.png);}");
    QPixmap pixmap1(":/res_items/1.png");
    fms.fm8->ui->btn1->setMask(QBitmap(pixmap1.mask()));
    fms.fm8->ui->btn1->setStyleSheet("QToolButton{border-image: url(:/res_items/1.png);}");
    QPixmap pixmap2(":/res_items/2.png");
    fms.fm8->ui->btn2->setMask(QBitmap(pixmap2.mask()));
    fms.fm8->ui->btn2->setStyleSheet("QToolButton{border-image: url(:/res_items/2.png);}");
    QPixmap pixmap3(":/res_items/3.png");
    fms.fm8->ui->btn3->setMask(QBitmap(pixmap3.mask()));
    fms.fm8->ui->btn3->setStyleSheet("QToolButton{border-image: url(:/res_items/3.png);}");
    QPixmap pixmap4(":/res_items/4.png");
    fms.fm8->ui->btn4->setMask(QBitmap(pixmap4.mask()));
    fms.fm8->ui->btn4->setStyleSheet("QToolButton{border-image: url(:/res_items/4.png);}");
    QPixmap pixmap5(":/res_items/5.png");
    fms.fm8->ui->btn5->setMask(QBitmap(pixmap5.mask()));
    fms.fm8->ui->btn5->setStyleSheet("QToolButton{border-image: url(:/res_items/5.png);}");
    QPixmap pixmap6(":/res_items/6.png");
    fms.fm8->ui->btn6->setMask(QBitmap(pixmap6.mask()));
    fms.fm8->ui->btn6->setStyleSheet("QToolButton{border-image: url(:/res_items/6.png);}");
    QPixmap pixmap7(":/res_items/7.png");
    fms.fm8->ui->btn7->setMask(QBitmap(pixmap7.mask()));
    fms.fm8->ui->btn7->setStyleSheet("QToolButton{border-image: url(:/res_items/7.png);}");
}
void Game::show_button_buy_thing()//显示可买物品
//0：刀 1：马 2：飞碟 3：铜拳套 4：银拳套 5：金拳套 6：弓 7：箭 8：炮 9：炮弹 10：雷 11：铜腰带 12：银腰带 13：金腰带
{
    static QString tmp[] = {"sword.png","horse.png","pearl.png", "stoneaxe.png","ironaxe.png","diamondaxe.png","bow.png"
        ,"arrow.png","cannon.png","cannonball.png","mine","stonestaff.png","ironstaff.png","diamondstaff.png"};

    int t = thing.size();
    qDebug() << "size:" << t;
    fms.fm8->ui->stackedWidget->setCurrentIndex(1);
    if (t > 0) {
        fms.fm8->ui->toolButton_b_0->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[0]]));
        fms.fm8->ui->toolButton_b_0->show();
    }
    if (t > 1) {
        fms.fm8->ui->toolButton_b_1->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[1]]));
        fms.fm8->ui->toolButton_b_1->show();
    }
    if (t > 2) {
        fms.fm8->ui->toolButton_b_2->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[2]]));
        fms.fm8->ui->toolButton_b_2->show();
    }
    if (t > 3) {
        fms.fm8->ui->toolButton_b_3->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[3]]));
        fms.fm8->ui->toolButton_b_3->show();
    }
    if (t > 4) {
        fms.fm8->ui->toolButton_b_4->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[4]]));
        fms.fm8->ui->toolButton_b_4->show();
    }
    if (t > 5) {
        fms.fm8->ui->toolButton_b_5->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[5]]));
        fms.fm8->ui->toolButton_b_5->show();
    }
    if (t > 6) {
        fms.fm8->ui->toolButton_b_6->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[6]]));
        fms.fm8->ui->toolButton_b_6->show();
    }
    if (t > 7) {
        fms.fm8->ui->toolButton_b_7->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[7]]));
        fms.fm8->ui->toolButton_b_7->show();
    }
    if (t > 8) {
        fms.fm8->ui->toolButton_b_8->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[8]]));
        fms.fm8->ui->toolButton_b_8->show();
    }
    if (t > 9) {
        fms.fm8->ui->toolButton_b_9->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[9]]));
        fms.fm8->ui->toolButton_b_9->show();
    }
    if (t > 10) {
        fms.fm8->ui->toolButton_b_10->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[10]]));
        fms.fm8->ui->toolButton_b_10->show();
    }
    if (t > 11) {
        fms.fm8->ui->toolButton_b_11->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[11]]));
        fms.fm8->ui->toolButton_b_11->show();
    }
    if (t > 12) {
        fms.fm8->ui->toolButton_b_12->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[12]]));
        fms.fm8->ui->toolButton_b_12->show();
    }
    if (t > 13) {
        fms.fm8->ui->toolButton_b_13->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[13]]));
        fms.fm8->ui->toolButton_b_13->show();
    }

}
void Game::hide_button_buy_thing()//隐藏可买物品
{
    fms.fm8->ui->toolButton_b_0->close();
    fms.fm8->ui->toolButton_b_1->close();
    fms.fm8->ui->toolButton_b_2->close();
    fms.fm8->ui->toolButton_b_3->close();
    fms.fm8->ui->toolButton_b_4->close();
    fms.fm8->ui->toolButton_b_5->close();
    fms.fm8->ui->toolButton_b_6->close();
    fms.fm8->ui->toolButton_b_7->close();
    fms.fm8->ui->toolButton_b_8->close();
    fms.fm8->ui->toolButton_b_9->close();
    fms.fm8->ui->toolButton_b_10->close();
    fms.fm8->ui->toolButton_b_11->close();
    fms.fm8->ui->toolButton_b_12->close();
    fms.fm8->ui->toolButton_b_13->close();

}
void Game::show_button_rob_thing()//显示可抢夺的物品
//0：衣服 1：刀 2：马 3：飞碟 4：铜拳套 5：银拳套 6：金拳套 7：弓 8：箭 9：炮 10：炮弹 11：雷 12：铜腰带 13：银腰带 14：金腰带
{
    static QString tmp[] = {"clothing.png","sword.png","horse.png","pearl.png", "stoneaxe.png","ironaxe.png","diamondaxe.png","bow.png"
        ,"arrow.png","cannon.png","cannonball.png","mine","stonestaff.png","ironstaff.png","diamondstaff.png"};

    int t = thing.size();
    qDebug() << "size:" << t;
    fms.fm8->ui->stackedWidget->setCurrentIndex(4);
    if (t > 0) {
        fms.fm8->ui->toolButton_r_0->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[0]]));
        fms.fm8->ui->toolButton_r_0->show();
    }
    if (t > 1) {
        fms.fm8->ui->toolButton_r_1->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[1]]));
        fms.fm8->ui->toolButton_r_1->show();
    }
    if (t > 2) {
        fms.fm8->ui->toolButton_r_2->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[2]]));
        fms.fm8->ui->toolButton_r_2->show();
    }
    if (t > 3) {
        fms.fm8->ui->toolButton_r_3->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[3]]));
        fms.fm8->ui->toolButton_r_3->show();
    }
    if (t > 4) {
        fms.fm8->ui->toolButton_r_4->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[4]]));
        fms.fm8->ui->toolButton_r_4->show();
    }
    if (t > 5) {
        fms.fm8->ui->toolButton_r_5->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[5]]));
        fms.fm8->ui->toolButton_r_5->show();
    }
    if (t > 6) {
        fms.fm8->ui->toolButton_r_6->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[6]]));
        fms.fm8->ui->toolButton_r_6->show();
    }
    if (t > 7) {
        fms.fm8->ui->toolButton_r_7->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[7]]));
        fms.fm8->ui->toolButton_r_7->show();
    }
    if (t > 8) {
        fms.fm8->ui->toolButton_r_8->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[8]]));
        fms.fm8->ui->toolButton_r_8->show();
    }
    if (t > 9) {
        fms.fm8->ui->toolButton_r_9->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[9]]));
        fms.fm8->ui->toolButton_r_9->show();
    }
    if (t > 10) {
        fms.fm8->ui->toolButton_r_10->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[10]]));
        fms.fm8->ui->toolButton_r_10->show();
    }
    if (t > 11) {
        fms.fm8->ui->toolButton_r_11->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[11]]));
        fms.fm8->ui->toolButton_r_11->show();
    }
    if (t > 12) {
        fms.fm8->ui->toolButton_r_12->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[12]]));
        fms.fm8->ui->toolButton_r_12->show();
    }
    if (t > 13) {
        fms.fm8->ui->toolButton_r_13->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[13]]));
        fms.fm8->ui->toolButton_r_13->show();
    }
    if (t > 14) {
        fms.fm8->ui->toolButton_r_14->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[14]]));
        fms.fm8->ui->toolButton_r_14->show();
    }
}
void Game::hide_button_rob_thing()//隐藏可抢夺的物品
{
    fms.fm8->ui->toolButton_r_0->close();
    fms.fm8->ui->toolButton_r_1->close();
    fms.fm8->ui->toolButton_r_2->close();
    fms.fm8->ui->toolButton_r_3->close();
    fms.fm8->ui->toolButton_r_4->close();
    fms.fm8->ui->toolButton_r_5->close();
    fms.fm8->ui->toolButton_r_6->close();
    fms.fm8->ui->toolButton_r_7->close();
    fms.fm8->ui->toolButton_r_8->close();
    fms.fm8->ui->toolButton_r_9->close();
    fms.fm8->ui->toolButton_r_10->close();
    fms.fm8->ui->toolButton_r_11->close();
    fms.fm8->ui->toolButton_r_12->close();
    fms.fm8->ui->toolButton_r_13->close();
    fms.fm8->ui->toolButton_r_14->close();
}

void Game::show_button_attack_thing()//显示可攻击的方式
{
    static QString tmp[] = {"sword.png","horse.png","stoneaxe.png","ironaxe.png","diamondaxe.png","bow.png"
        ,"cannon.png","mine","stonestaff.png","ironstaff.png","diamondstaff.png"
        ,"potion1.png","potion2.png","mine_t.png"};

    int t = thing.size();
    qDebug() << "size:" << t;
    fms.fm8->ui->stackedWidget->setCurrentIndex(0);
    if (t > 0) {
        fms.fm8->ui->toolButton_a_0->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[0]]));
        fms.fm8->ui->toolButton_a_0->show();
    }
    if (t > 1) {
        fms.fm8->ui->toolButton_a_1->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[1]]));
        fms.fm8->ui->toolButton_a_1->show();
    }
    if (t > 2) {
        fms.fm8->ui->toolButton_a_2->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[2]]));
        fms.fm8->ui->toolButton_a_2->show();
    }
    if (t > 3) {
        fms.fm8->ui->toolButton_a_3->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[3]]));
        fms.fm8->ui->toolButton_a_3->show();
    }
    if (t > 4) {
        fms.fm8->ui->toolButton_a_4->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[4]]));
        fms.fm8->ui->toolButton_a_4->show();
    }
    if (t > 5) {
        fms.fm8->ui->toolButton_a_5->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[5]]));
        fms.fm8->ui->toolButton_a_5->show();
    }
    if (t > 6) {
        fms.fm8->ui->toolButton_a_6->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[6]]));
        fms.fm8->ui->toolButton_a_6->show();
    }
    if (t > 7) {
        fms.fm8->ui->toolButton_a_7->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[7]]));
        fms.fm8->ui->toolButton_a_7->show();
    }
    if (t > 8) {
        fms.fm8->ui->toolButton_a_8->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[8]]));
        fms.fm8->ui->toolButton_a_8->show();
    }
    if (t > 9) {
        fms.fm8->ui->toolButton_a_9->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[9]]));
        fms.fm8->ui->toolButton_a_9->show();
    }
    if (t > 10) {
        fms.fm8->ui->toolButton_a_10->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[10]]));
        fms.fm8->ui->toolButton_a_10->show();
    }
    if (t > 11) {
        fms.fm8->ui->toolButton_a_11->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[11]]));
        fms.fm8->ui->toolButton_a_11->show();
    }
    if (t > 12) {
        fms.fm8->ui->toolButton_a_12->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[12]]));
        fms.fm8->ui->toolButton_a_12->show();
    }
    if (t > 13) {
        fms.fm8->ui->toolButton_a_13->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(tmp[thing[13]]));
        fms.fm8->ui->toolButton_a_13->show();
    }
}
void Game::hide_button_attack_thing()//隐藏可攻击的方式
{
    fms.fm8->ui->toolButton_a_0->close();
    fms.fm8->ui->toolButton_a_1->close();
    fms.fm8->ui->toolButton_a_2->close();
    fms.fm8->ui->toolButton_a_3->close();
    fms.fm8->ui->toolButton_a_4->close();
    fms.fm8->ui->toolButton_a_5->close();
    fms.fm8->ui->toolButton_a_6->close();
    fms.fm8->ui->toolButton_a_7->close();
    fms.fm8->ui->toolButton_a_8->close();
    fms.fm8->ui->toolButton_a_9->close();
    fms.fm8->ui->toolButton_a_10->close();
    fms.fm8->ui->toolButton_a_11->close();
    fms.fm8->ui->toolButton_a_12->close();
    fms.fm8->ui->toolButton_a_13->close();
}
void Game::show_highlight_position_attack(bitset<9> flag)//显示攻击下属位置高亮
{
    fms.fm8->ui->btn_mv_0->show();
    fms.fm8->ui->btn_mv_1->show();
    fms.fm8->ui->btn_mv_2->show();
    fms.fm8->ui->btn_mv_3->show();
    fms.fm8->ui->btn_mv_4->show();
    fms.fm8->ui->btn_mv_5->show();
    fms.fm8->ui->btn_mv_6->show();
    fms.fm8->ui->btn_mv_7->show();
    fms.fm8->ui->btn_mv_8->show();

    fms.fm8->ui->btn_mv_0->setEnabled(flag[0]);
    fms.fm8->ui->btn_mv_1->setEnabled(flag[1]);
    fms.fm8->ui->btn_mv_2->setEnabled(flag[2]);
    fms.fm8->ui->btn_mv_3->setEnabled(flag[3]);
    fms.fm8->ui->btn_mv_4->setEnabled(flag[4]);
    fms.fm8->ui->btn_mv_5->setEnabled(flag[5]);
    fms.fm8->ui->btn_mv_6->setEnabled(flag[6]);
    fms.fm8->ui->btn_mv_7->setEnabled(flag[7]);
    fms.fm8->ui->btn_mv_8->setEnabled(flag[8]);

    QPixmap pixmap0(QString(":/res_items/%1").arg(flag[0]?"btn_green.png":"btn_red.png"));
//    fms.fm8->ui->btn_mv_0->move(228,2);
//    fms.fm8->ui->btn_mv_0->move(390,65);
//    fms.fm8->ui->btn_mv_0->move(456,226);
//    fms.fm8->ui->btn_mv_0->move(395,388);
//    fms.fm8->ui->btn_mv_0->move(233,456);
//    fms.fm8->ui->btn_mv_0->move(69,393);
//    fms.fm8->ui->btn_mv_0->move(3,231);
//    fms.fm8->ui->btn_mv_0->move(66,68);
    fms.fm8->ui->btn_mv_0->resize(pixmap0.size());
    fms.fm8->ui->btn_mv_0->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[0]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap1(QString(":/res_items/%1").arg(flag[1]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_1->resize(pixmap1.size());
    fms.fm8->ui->btn_mv_1->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[1]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap2(QString(":/res_items/%1").arg(flag[2]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_2->resize(pixmap2.size());
    fms.fm8->ui->btn_mv_2->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[2]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap3(QString(":/res_items/%1").arg(flag[3]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_3->resize(pixmap3.size());
    fms.fm8->ui->btn_mv_3->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[3]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap4(QString(":/res_items/%1").arg(flag[4]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_4->resize(pixmap4.size());
    fms.fm8->ui->btn_mv_4->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[4]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap5(QString(":/res_items/%1").arg(flag[5]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_5->resize(pixmap5.size());
    fms.fm8->ui->btn_mv_5->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[5]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap6(QString(":/res_items/%1").arg(flag[6]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_6->resize(pixmap6.size());
    fms.fm8->ui->btn_mv_6->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[6]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap7(QString(":/res_items/%1").arg(flag[7]?"btn_green.png":"btn_red.png"));
    fms.fm8->ui->btn_mv_7->resize(pixmap7.size());
    fms.fm8->ui->btn_mv_7->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[7]?"btn_green.png":"btn_red.png"));
    QPixmap pixmap8(QString(":/res_items/%1").arg(flag[8]?"btn_green_8.png":"btn_red_8.png"));
    fms.fm8->ui->btn_mv_8->resize(pixmap8.size());
    fms.fm8->ui->btn_mv_8->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[8]?"btn_green_8.png":"btn_red_8.png"));

}
void Game::hide_highlight_position_attack()//隐藏攻击下属位置高亮
{
    fms.fm8->ui->btn_mv_0->close();
    fms.fm8->ui->btn_mv_1->close();
    fms.fm8->ui->btn_mv_2->close();
    fms.fm8->ui->btn_mv_3->close();
    fms.fm8->ui->btn_mv_4->close();
    fms.fm8->ui->btn_mv_5->close();
    fms.fm8->ui->btn_mv_6->close();
    fms.fm8->ui->btn_mv_7->close();
    fms.fm8->ui->btn_mv_8->close();
}
void Game::show_highlight_player_attack(bitset<8> flag)//显示攻击下属玩家高亮
{
    fms.fm8->ui->btn0->setEnabled(flag[0]);
    fms.fm8->ui->btn1->setEnabled(flag[1]);
    fms.fm8->ui->btn2->setEnabled(flag[2]);
    fms.fm8->ui->btn3->setEnabled(flag[3]);
    fms.fm8->ui->btn4->setEnabled(flag[4]);
    fms.fm8->ui->btn5->setEnabled(flag[5]);
    fms.fm8->ui->btn6->setEnabled(flag[6]);
    fms.fm8->ui->btn7->setEnabled(flag[7]);

    QPixmap pixmap0(QString(":/res_items/%1").arg(flag[0]?"0g.png":"0r.png"));
    fms.fm8->ui->btn0->setMask(QBitmap(pixmap0.mask()));
    fms.fm8->ui->btn0->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[0]?"0g.png":"0r.png"));
    QPixmap pixmap1(QString(":/res_items/%1").arg(flag[1]?"1g.png":"1r.png"));
    fms.fm8->ui->btn1->setMask(QBitmap(pixmap1.mask()));
    fms.fm8->ui->btn1->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[1]?"1g.png":"1r.png"));
    QPixmap pixmap2(QString(":/res_items/%1").arg(flag[2]?"2g.png":"2r.png"));
    fms.fm8->ui->btn2->setMask(QBitmap(pixmap2.mask()));
    fms.fm8->ui->btn2->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[2]?"2g.png":"2r.png"));
    QPixmap pixmap3(QString(":/res_items/%1").arg(flag[3]?"3g.png":"3r.png"));
    fms.fm8->ui->btn3->setMask(QBitmap(pixmap3.mask()));
    fms.fm8->ui->btn3->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[3]?"3g.png":"3r.png"));
    QPixmap pixmap4(QString(":/res_items/%1").arg(flag[4]?"4g.png":"4r.png"));
    fms.fm8->ui->btn4->setMask(QBitmap(pixmap4.mask()));
    fms.fm8->ui->btn4->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[4]?"4g.png":"4r.png"));
    QPixmap pixmap5(QString(":/res_items/%1").arg(flag[5]?"5g.png":"5r.png"));
    fms.fm8->ui->btn5->setMask(QBitmap(pixmap5.mask()));
    fms.fm8->ui->btn5->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[5]?"5g.png":"5r.png"));
    QPixmap pixmap6(QString(":/res_items/%1").arg(flag[6]?"6g.png":"6r.png"));
    fms.fm8->ui->btn6->setMask(QBitmap(pixmap6.mask()));
    fms.fm8->ui->btn6->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[6]?"6g.png":"6r.png"));
    QPixmap pixmap7(QString(":/res_items/%1").arg(flag[7]?"7g.png":"7r.png"));
    fms.fm8->ui->btn7->setMask(QBitmap(pixmap7.mask()));
    fms.fm8->ui->btn7->setStyleSheet(QString("QToolButton{border-image: url(:/res_items/%1);}").arg(flag[7]?"7g.png":"7r.png"));
}
void Game::hide_highlight_player_attack()//隐藏攻击下属玩家高亮
{
    fms.fm8->ui->btn0->setEnabled(0);
    fms.fm8->ui->btn1->setEnabled(0);
    fms.fm8->ui->btn2->setEnabled(0);
    fms.fm8->ui->btn3->setEnabled(0);
    fms.fm8->ui->btn4->setEnabled(0);
    fms.fm8->ui->btn5->setEnabled(0);
    fms.fm8->ui->btn6->setEnabled(0);
    fms.fm8->ui->btn7->setEnabled(0);

    QPixmap pixmap0(":/res_items/0.png");
    fms.fm8->ui->btn0->setMask(QBitmap(pixmap0.mask()));
    fms.fm8->ui->btn0->setStyleSheet("QToolButton{border-image: url(:/res_items/0.png);}");
    QPixmap pixmap1(":/res_items/1.png");
    fms.fm8->ui->btn1->setMask(QBitmap(pixmap1.mask()));
    fms.fm8->ui->btn1->setStyleSheet("QToolButton{border-image: url(:/res_items/1.png);}");
    QPixmap pixmap2(":/res_items/2.png");
    fms.fm8->ui->btn2->setMask(QBitmap(pixmap2.mask()));
    fms.fm8->ui->btn2->setStyleSheet("QToolButton{border-image: url(:/res_items/2.png);}");
    QPixmap pixmap3(":/res_items/3.png");
    fms.fm8->ui->btn3->setMask(QBitmap(pixmap3.mask()));
    fms.fm8->ui->btn3->setStyleSheet("QToolButton{border-image: url(:/res_items/3.png);}");
    QPixmap pixmap4(":/res_items/4.png");
    fms.fm8->ui->btn4->setMask(QBitmap(pixmap4.mask()));
    fms.fm8->ui->btn4->setStyleSheet("QToolButton{border-image: url(:/res_items/4.png);}");
    QPixmap pixmap5(":/res_items/5.png");
    fms.fm8->ui->btn5->setMask(QBitmap(pixmap5.mask()));
    fms.fm8->ui->btn5->setStyleSheet("QToolButton{border-image: url(:/res_items/5.png);}");
    QPixmap pixmap6(":/res_items/6.png");
    fms.fm8->ui->btn6->setMask(QBitmap(pixmap6.mask()));
    fms.fm8->ui->btn6->setStyleSheet("QToolButton{border-image: url(:/res_items/6.png);}");
    QPixmap pixmap7(":/res_items/7.png");
    fms.fm8->ui->btn7->setMask(QBitmap(pixmap7.mask()));
    fms.fm8->ui->btn7->setStyleSheet("QToolButton{border-image: url(:/res_items/7.png);}");
}
void Game::show_button_back()
{
    fms.fm8->ui->toolButton_4->setVisible(true);
}
void Game::hide_button_back()
{
    fms.fm8->ui->toolButton_4->setVisible(false);
}
void Game::print_winner(int winner)//
{
    fms.fm8->hide();
    QMessageBox m(QMessageBox::Information, "游戏结束", winner != -1 ? (player[winner].name + "胜利！").c_str() : "无人生还", QMessageBox::Yes);
    m.exec();
    exit(0);
}
