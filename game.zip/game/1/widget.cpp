#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    server=new QTcpServer;
    server->listen(QHostAddress::Any,Port2);

    socket=new QTcpSocket;
    socket->connectToHost(IP,Port);
    connect(socket,SIGNAL(readyRead()),this,SLOT(roomAddress()));

    master=new QTcpSocket;

    server=new QTcpServer;
    connect(server,SIGNAL(newConnection()),this,SLOT(newClient()));
    connect(server,SIGNAL(readyRead()),this,SLOT(broadInformation()));

    if(!socket->waitForConnected()) {
        ui->label->setText("抱歉，未连接上服务器");
    }
}

QString localAddress() {
    QString ret;
    QHostInfo hostInfo=QHostInfo::fromName(QHostInfo::localHostName());
    QList<QHostAddress>addresses=hostInfo.addresses();
    foreach(const QHostAddress &address,addresses) {
        if(address.protocol()==QAbstractSocket::IPv4Protocol) {
            ret=address.toString();
        }
    }
    return ret;
}

Widget::~Widget()
{
    socket->disconnectFromHost();
    qDebug()<<"disconnect";
    if(!fangzhu) master->disconnectFromHost();
    delete ui;
}

void Widget::roomAddress() {
    QByteArray data=socket->readAll();
    qDebug()<<data.at(0);
    if(data.at(0)==0)  {
        qDebug()<<"Sorry";
        //tryAgain();
    } else if(data.at(0)==1){
        qDebug()<<"Right!";
        if(zujian) {
            fangzhu=1;
            qDebug()<<"master "+localAddress().toStdString();
        } else {
            QByteArray roomIP = data.mid(1);
            QString result(roomIP);
            fangzhu=0;
            master->connectToHost(result,Port2);
            connect(master,SIGNAL(readyRead()),this,SLOT(reaction()));
            qDebug()<<"connected to the room master"+result;
        }
    } else if(data.at(0)==2) {
        qDebug()<<"room has destroyed";
        //弹出Debug（）
        //房间炸了
        //GameOver();
    } else if(data.at(0)==3) {
        QByteArray roomIP = data.mid(1);
        QString result(roomIP);
        qDebug()<<"Client "+result+" has disconnected";
    //    socket->disconnectFromHost();
        //弹出Debug()
        //GameOver();
    } else if(data.at(0)==4){
        qDebug()<<"Server has destroyed";
        //弹出Debug();
        //GameOver();
    }
}
void Widget::newClient() {
    QTcpSocket* tmp = server->nextPendingConnection();
    sockets.append(tmp);
    connect(tmp,SIGNAL(disconnected()),this,SLOT(delClient()));
}

void Widget::delClient() {
    qDebug()<<"A machine went away";
    //弹出qDebug()
    for(auto t:sockets) {
        t->deleteLater();
    }
    //Gameover();
}
void Widget::broadInformation() {
    QTcpSocket* tmp = qobject_cast<QTcpSocket*>(sender());
    QByteArray data = tmp->readAll();
    //dispose data;
    for(auto t:sockets) {
        t->write(data);
        t->flush();
    }
    qDebug()<<"broadAll";
}
void Widget::reaction() {
    QByteArray data = master->readAll();
    //dispose data //在读入之前不对原来进行修改
    qDebug()<<"receive "+data+" successfully! ";
}


void Widget::on_buildButton_clicked()
{
    QString tmp=ui->buildName->text();
    socket->write((tmp.toStdString()+"+0").c_str());
}



void Widget::on_addButton_clicked()
{
    QString tmp=ui->addName->text();
    socket->write((tmp.toStdString()+"+1").c_str());
}



void Widget::on_sendButton_clicked()
{
    QByteArray data=ui->send->text().toStdString().c_str();
    if(!fangzhu) {
        master->write(data);
        master->flush();
        qDebug()<<"send to the master";
    } else {
        //dispose data;
        for(auto t:sockets) {
            t->write(data);
            t->flush();
        }
        qDebug()<<"send to the sockets";
    }
}

