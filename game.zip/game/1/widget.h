#ifndef WIDGET_H
#define WIDGET_H

#include<QTcpSocket>
#include<QTcpServer>
#include<QHostInfo>
#include <QWidget>

#define IP "10.6.165.222"
#define Port 8000
#define Port2 6666
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    QTcpSocket *socket,*master;
    QTcpServer *server;
    QList<QTcpSocket*> sockets;

private slots:
    void broadInformation();
    void newClient();
    void delClient();
    void reaction();
    void roomAddress();

    void on_buildButton_clicked();

    void on_addButton_clicked();

    void on_sendButton_clicked();

private:
    Ui::Widget *ui;
    bool fangzhu,zujian=1;
};
#endif // WIDGET_H
