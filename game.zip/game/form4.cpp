#include "form4.h"
#include "ui_form4.h"
#include "formmanage.h"
#include "game.h"
#include "client.h"

Form4::Form4(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form4)
{
    ui->setupUi(this);
    connect(ui->toolButton, &QToolButton::clicked, this, [=](){
        game.room = ui->lineEdit->text();
        qDebug() << game.room;
        if (game.fz)
            client->socket->write((game.room + QString::fromStdString("+0")).toStdString().c_str());
        else
            client->socket->write((game.room + QString::fromStdString("+1")).toStdString().c_str());
        fms.fm5->show2();
        this->hide();
    });
}

Form4::~Form4()
{
    delete ui;
}
