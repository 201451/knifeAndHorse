#include "formmanage.h"
#include "game.h"
#include "client.h"
#include <QApplication>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    fms.open();
    client = new Client;
    fms.fm1->show();
    return a.exec();
}
