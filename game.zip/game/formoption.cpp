#include "formoption.h"
#include "ui_formoption.h"

FormOption::FormOption(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormOption)
{
    ui->setupUi(this);
    //音乐

    //返回
    connect(ui->toolButton_2, &QToolButton::clicked, this, [=](){
        this->back->show();
        delete this;
    });
}


void FormOption::set_back_form(QWidget *b) {
    back = b;
}
FormOption::~FormOption()
{
    delete ui;
}
