#ifndef GAME_H
#define GAME_H

#include <QObject>
#include <string>
#include <vector>
#include <bitset>
#include <QMessageBox>

using std::string;
using std::vector;
using std::bitset;


class Position
{
public:
    int item[6];//0 第一种地雷 1 第二种地雷 2 下回合生效的药水 3 这回合生效的药水 4 下回合生效的炮弹 5 这回合生效的炮弹
};
class Player
{
public:
    string name;
    int hp,role;//1 外星人 2 拳击手 3 法师 4 弓箭手 5 炮手 6 雷兵 7 胖子 8 气功大师 9 吸血鬼
    int position;//8 中心区域 0~7 为玩家 0~7 的初始城池
    int team;
    bool die;
    int equipment[15];//0：衣服 1：刀 2：马 3：飞碟 4：铜拳套 5：银拳套 6：金拳套 7：弓 8：箭 9：炮 10：炮弹 11：雷 12：铜腰带 13：银腰带 14：金腰带
    int right[14];//0：刀 1：马 2：飞碟 3：铜拳套 4：银拳套 5：金拳套 6：弓 7：箭 8：炮 9：炮弹 10：雷 11：铜腰带 12：银腰带 13：金腰带
};

class Game : public QObject
{
    Q_OBJECT
public:
    explicit Game(QObject *parent = nullptr);
    int n;//人数
    int c[10];
    vector<int> thing;
    Position position[9];
    Player player[8];
    int rem[8],tmp[8];
    int person[2]; //两个雷兵的编号
    int now_person;
    int cost[14]={1,1,2,1,2,3,2,1,2,2,1,1,2,3};
    vector<int> action_list;
    int myself;
    int fz, readycount=0;
    QString room;
    QString name;
    string information;
    int stop;
    int n_person;
    bitset<9> where_to_move(int x);
    void next();
    void move(int x,int destination);
    void move_plus(int x,int destination,int y);
    bitset<8> who_to_touch(int x);
    bitset<8> who_to_touch_plus(int x);
    void rob(int x,int y,int equipment);
    void buy(int x,int equipment);
    bool no_clothing(int x);
    void check(int x,int y);
    void check(int x);
    void rand_to_go(int x);
    void attack(int x,int means,int y);
    void round_over();
    int game_over();
    void click_guess(int x);
    void click_move();
    void click_move_where(int x);
    void click_move_where_who(int x);
    void click_buy();
    void click_buy_what(int x);
    void click_rob();
    void click_rob_who(int x);
    void click_rob_who_what(int x);
    void click_attack();
    void click_attack_what(int x);
    void click_attack_what_who(int y);
    void game_start();
    void game_start_single();
    void game_start_team(const vector<string> &name,const vector<int> &role,const vector<int> &team);
    void send(string s);//首位为 1 表示移动 2 表示购买 3 表示抢夺 4 表示攻击 5 表示石头剪刀布处理
    void receive(string s);//首位为 1 表示移动 2 表示购买 3 表示抢夺 4 表示攻击 5 表示石头剪刀布处理
    void show_button_guess();//展示剪刀石头布按钮
    void hide_button_guess();//隐藏剪刀石头布按钮
    void show_button_action();//展示移动购买抢夺攻击按钮
    void hide_button_action();//隐藏移动购买抢夺攻击按钮
    void show_button_back();
    void hide_button_back();
    void print();//打印状态栏 打印时按照action_list顺序打印，并检查该人是否死亡，若!player[x].die，则打印该人状态
    void show_highlight_position_move(bitset<9> flag);//显示移动下属位置高亮
    void hide_highlight_position_move();//隐藏移动下属位置高亮
    void show_highlight_player_move(bitset<8> flag);//显示胖子移动带人的高亮
    void hide_highlight_player_move();//隐藏胖子移动带人的高亮
    void show_highlight_player_rob(bitset<8> flag);//显示抢夺下属玩家高亮
    void hide_highlight_player_rob();//隐藏抢夺下属玩家高亮
    void show_button_buy_thing();//显示可买物品
    void hide_button_buy_thing();//隐藏可买物品
    void show_button_rob_thing();//显示可抢夺的物品
    void hide_button_rob_thing();//隐藏可抢夺的物品
    void show_button_attack_thing();//显示可攻击的方式
    void hide_button_attack_thing();//隐藏可攻击的方式
    void show_highlight_position_attack(bitset<9> flag);//显示攻击下属位置高亮
    void hide_highlight_position_attack();//隐藏攻击下属位置高亮
    void show_highlight_player_attack(bitset<8> flag);//显示攻击下属玩家高亮
    void hide_highlight_player_attack();//隐藏攻击下属玩家高亮
    void print_winner(int winner);//打印胜者

signals:

};
extern Game game;

#endif // GAME_H
