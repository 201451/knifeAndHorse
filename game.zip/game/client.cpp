#include "client.h"
#include <QDebug>
#include "game.h"

Client *client;

Client::Client(QWidget *parent)
    : QWidget(parent)
{

    socket=new QTcpSocket;
    socket->connectToHost(IP,Port);
    connect(socket,&QTcpSocket::readyRead,this,&Client::roomAddress);
    if(!socket->waitForConnected()) {
        QMessageBox m(QMessageBox::Information, "错误", "无法连接服务器", QMessageBox::Yes);
        m.exec();
        exit(0);
    }
}
Client::~Client()
{
    socket->disconnectFromHost();
    qDebug()<<"disconnect";
}

void Client::roomAddress() {
    QByteArray data=socket->readAll();
    game.receive(QString(data).toStdString());
    return;
   // qDebug()<<"data.at(0)="<<data.at(0)<<data.at(0)<<data.at(0)==1;
    if(data.at(0)=='0') {
        qDebug()<<"Sorry";
        //tryAgain();
    } else if(data.at(0)=='1'){
        qDebug()<<"Right!";
    } else if(data.at(0)=='2') {
        QByteArray information=data.mid(1);
        //dispose information
    } else if(data.at(0)=='3') {
        QByteArray nameList=data.mid(1);

        //dispose nameList
    } else if(data.at(0)=='4'){
        qDebug()<<"Room has destroyed";
        //弹出Debug();
        //GameOver();
    } else {
        qDebug()<<"Server has destroyed";
        //GameOVer();
    }
}
