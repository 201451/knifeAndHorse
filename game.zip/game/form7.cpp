#include "form7.h"
#include "ui_form7.h"
#include "formmanage.h"
#include "game.h"
#include "client.h"

Form7::Form7(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form7)
{
    ui->setupUi(this);
//    connect();选择英雄按钮
}

Form7::~Form7()
{
    delete ui;
}
void Form7::on_toolButton_clicked()
{
    role = 1;
    ui->label_2->setText("当前选择：外星人");
}


void Form7::on_toolButton_2_clicked()
{
    role = 2;
    ui->label_2->setText("当前选择：拳击手");
}
void Form7::on_toolButton_3_clicked()
{
    role = 3;
    ui->label_2->setText("当前选择：法师");
}

void Form7::on_toolButton_4_clicked()
{
    role = 4;
    ui->label_2->setText("当前选择：弓箭手");
}

void Form7::on_toolButton_5_clicked()
{
    role = 5;
    ui->label_2->setText("当前选择：炮手");
}

void Form7::on_toolButton_6_clicked()
{
    role = 6;
    ui->label_2->setText("当前选择：雷兵");
}

void Form7::on_toolButton_7_clicked()
{
    role = 7;
    ui->label_2->setText("当前选择：胖子");
}

void Form7::on_toolButton_8_clicked()
{
    role = 8;
    ui->label_2->setText("当前选择：气功大师");
}

void Form7::on_toolButton_9_clicked()
{
    role = 9;
    ui->label_2->setText("当前选择：吸血鬼");
}



void Form7::on_readyButton_clicked()
{
    if (role != 0 && game.c[role] > 0) {
        game.information[0] = 6;
        game.information[1] = game.myself;
        game.information[2] = role;
        game.send(game.information);
        ui->readyButton->close();
    }
}

