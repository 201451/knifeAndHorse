#include "form3.h"
#include "ui_form3.h"
#include "formmanage.h"
#include "game.h"

Form3::Form3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form3)
{
    ui->setupUi(this);
    //加入房间
    connect(ui->toolButton, &QToolButton::clicked, this, [=](){
        game.fz = 0;
        fms.fm4->show();
        this->hide();
    });

    //创建房间
    connect(ui->toolButton_2, &QToolButton::clicked, this, [=](){
        game.fz = 1;
        fms.fm4->show();
        this->hide();
    });
}

Form3::~Form3()
{
    delete ui;
}

void Form3::on_toolButton_clicked()
{
    game.fz = 0;
}

void Form3::on_toolButton_2_clicked()
{
    game.fz = 1;
}

