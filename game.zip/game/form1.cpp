#include "form1.h"
#include "ui_form1.h"
#include "formmanage.h"

Form1::Form1(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    //开始游戏
    connect(ui->btn1, &QPushButton::clicked, this, [=](){
        fms.fm2->show();
        this->hide();
    });

    //游戏规则
    connect(ui->btn2, &QPushButton::clicked, this, [=](){
        FormIntroduction *fmin = new FormIntroduction();
        fmin->set_back_form(this);
        fmin->show();
        this->hide();
    });

    //选项
    connect(ui->btn3, &QPushButton::clicked, this, [=](){
        FormOption *fmop = new FormOption();
        fmop->set_back_form(this);
        fmop->show();
        this->hide();
    });

    //退出游戏
    connect(ui->btn4, &QPushButton::clicked, this, &QWidget::close);

}

Form1::~Form1()
{
    delete ui;
}
